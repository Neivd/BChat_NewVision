import Client.DATA.Common.*;
import Client.DATA.Common.Event;

import javax.swing.*;
import java.awt.*;

public class UserInterface {
    private final JFrame jf;
    Event event;
    Safe safe=Safe.getInstance();
    JList<String> list=new JList<>();
    ButtonItem[] buttons;
    public UserInterface(String title,Safe safe){
        jf=new JFrame(title);
        this.safe=safe;
    }
    public UserInterface(){
        jf=new JFrame("nmsl");
        System.out.println("Warn,this test mode is danger");
    }

    public static void main(String[] args) {
        Beautiful.setUIFont();
        new UserInterface().build();
    }
    void  build(){
        Box rightBox=Box.createVerticalBox();
        Box leftPane= Box.createVerticalBox();
        leftPane.add(new JLabel("Online:"));
        leftPane.add(list);
        JSplitPane splitPane= Show.createSplitPane(leftPane,rightBox);

        buttons=new ButtonItem[]{new ButtonItem("Exit",(e)->{safe.exit(0);})};

        for(ButtonItem i:buttons){
            rightBox.add(i.getButton());
        }
        jf.setIconImage(Show.getImage());
        jf.setContentPane(splitPane);
        jf.setMinimumSize(new Dimension(500,400));
        Beautiful.setBorder(splitPane);
        Beautiful.setMid(jf);
        jf.setVisible(true);
    }
}
