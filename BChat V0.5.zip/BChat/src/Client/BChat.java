package Client;


import Client.DATA.Common.Beautiful;
import Client.DATA.Common.Event;
import Client.DATA.Common.Show;
import Client.DATA.Common.Tools;
import Client.DATA.Information;
import Client.DATA.Net;

import java.awt.*;
import java.util.ArrayList;

public class BChat {
    private final Event event=Event.getInstance();
    public static void main(String[] args){
        Beautiful.setUIFont();
        new BChat().build();
    }

    private void build(){
        //Show.m("info",System.getProperty("user.dir"));
        //self check
        ArrayList<String> selfCheckInfo=new ArrayList<>();
        if(!SystemTray.isSupported()){
            selfCheckInfo.add("Your system do not support system tray.some features may be influenced.\n");
        }
        if(!Desktop.isDesktopSupported()){
            selfCheckInfo.add("Your system don't support operate desktop application,some features may be influenced.\n");
        }
        if(selfCheckInfo.size()!=0){
            event.add(Event.Warn, "Warning", Tools.linkStr("We find ", String.valueOf(selfCheckInfo.size()), " problems:\n",
                    selfCheckInfo.toString()), true);
        }
        Show.init();



        Net net = new Net(Information.IP, Information.com,event);
        net.run();

    }

}