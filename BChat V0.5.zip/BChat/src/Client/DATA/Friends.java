package Client.DATA;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Friends implements Serializable {
    //public ArrayList<String> map;
    Map<String, Friend> nameMap = new HashMap<>();
    //ArrayList<Friend> allFrd=new ArrayList<>();
    String userID;

    public Friends(String ID) {
        userID = ID;
    }

    void addAllFrd(ArrayList<Friend> frd) {
        //allFrd=frd;
        for (Friend i : frd) {
            nameMap.put(i.UID, i);
        }
    }
    void addFrd(Friend i) {
        nameMap.put(i.UID, i);
    }
}