package Client.DATA.Common;

@FunctionalInterface
public interface MsgInterface {
    void message(String info);
}
