package Client.DATA.Common;

import com.google.gson.Gson;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.util.Date;

public class Tools {
    public static final Gson GSON=new Gson();
    private static final StringBuilder str =new StringBuilder();
    private static final Desktop desktop=Desktop.getDesktop();
    private static void clearTempStr(){
        str.replace(0, str.length(),"");
    }
    public static String linkStr(String a,String b){
        clearTempStr();
        return str.append(a).append(b).toString();
    }
    public static String linkStr(String a,String b,String c){
        clearTempStr();
        str.append(a);
        str.append(b);
        str.append(c);
        return str.toString();
    }
    public static String linkStr(String a,String b,String c,String d){
        clearTempStr();
        str.append(a);
        str.append(b);
        str.append(c);
        str.append(d);
        return str.toString();
    }
    public static String linkStr(String a,String b,String c,String d,String e){
        clearTempStr();
        return str.append(a).append(b).append(c).append(d).append(e).toString();
    }
    public static String linkStr(String... strings){
        clearTempStr();
        for(String i: strings){
            str.append(i);
        }
        return str.toString();
    }
    public static String getTime(){
        return new Date().toString();
    }
    public static String getTimeWithoutColon(){
        return getTime().replace(':','.');
    }
    public static BufferedImage takeScreenshots() throws AWTException {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        // 创建需要截取的矩形区域
        Rectangle rect = new Rectangle(0, 0, screenSize.width, screenSize.height);
        // 截屏操作
        return new Robot().createScreenCapture(rect);
    }
    public static void browse(String url) throws IOException {
        desktop.browse(URI.create(url));
    }
    public static void open(String add) throws IOException {
        desktop.open(new File(add));
    }
    public static void makeRun(Runnable thing) {
        Thread newThread = new Thread(thing);
        newThread.start();
    }
    public static void autoCloseWindow(Window jd,long time){
        Tools.makeRun(()->{
            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            jd.dispose();
        });
    }
    public static String readFile(String path) throws IOException {
        BufferedReader br=new BufferedReader(new FileReader(path));
        String s;
        StringBuilder all=new StringBuilder();
        while ((s=br.readLine())!=null){
            all.append(s);
        }
        return all.toString();
    }
    public static void writeFile(String path,String content) throws IOException {
        BufferedWriter bw=new BufferedWriter(new FileWriter(path));
        bw.write(content);
        bw.close();
    }
}
