package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;

public class Show {
    static ImageIcon icon;
    static boolean isBuff = false;
    static Image image;

    public static void init() {
        try {
            icon = new ImageIcon("block.png");
            image = Toolkit.getDefaultToolkit().getImage("block.png");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("error");
        }
        isBuff = true;
    }

    public static void m(String t, String msg) {
        //System.out.println(System.getProperty("user.dir"));
        JOptionPane.showMessageDialog(null, msg, t, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void m(Window frame, String t, String msg) {
        JOptionPane.showMessageDialog(frame, msg, t, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showPhoto() {
        JFrame jf = new JFrame("test");
        jf.setIconImage(getImage());
        jf.getContentPane().add(new JLabel(getIco()));
        jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        jf.pack();
        jf.setSize(300, 300);
        Beautiful.setMid(jf);
        jf.setVisible(true);
    }

    public static void main(String[] args) {
        floatWindow("new JFrame(),","qwe",1000);
        System.out.println(System.getProperty("user.dir"));
/*        StringBuilder sb = new StringBuilder();
        sb.append("?".repeat(10000));
        m(sb.toString(), sb.toString());*/
        //showPhoto();
        //m("title","test,test,test,test,test,test,test.");
    }

    public static ImageIcon getIco() {
        if (!isBuff) {
            init();
        }
        return (icon);
    }

    public static Image getImage() {
        if (!isBuff) {
            init();
        }
        return (image);
    }
    public static void confirm(Window window,String title,String info,MsgInterface msgInterface){
        JFrame jf=new JFrame(title);
        jf.setIconImage(getImage());
        Box p=Box.createVerticalBox();
        jf.setContentPane(p);
        Beautiful.setBorder(p);
        JTextArea txt=Beautiful.createText(info,true);
        p.add(Beautiful.CreatScroll(txt));
        Box buttons= Box.createHorizontalBox();
        JButton yes=new JButton("Confirm");
        JButton no=new JButton("Cancel");
        buttons.add(Box.createHorizontalGlue());
        buttons.add(yes);
        buttons.add(Box.createHorizontalGlue());
        buttons.add(no);
        buttons.add(Box.createHorizontalGlue());
        p.add(buttons);
        no.addActionListener((e)->jf.dispose());
        yes.addActionListener((e)-> {
            jf.dispose();
            msgInterface.message(txt.getText());

        });

        jf.setMinimumSize(new Dimension(300,200));
        jf.pack();
        jf.setLocationRelativeTo(window);
        jf.setVisible(true);
    }
    public static void confirm(Window f,String title,String info,Runnable run){
        //close window or press cancel mean cancel
        JFrame jf=new JFrame(title);
        jf.setIconImage(getImage());
        Box p=Box.createVerticalBox();
        jf.setContentPane(p);
        Beautiful.setBorder(p);
        JTextArea txt=Beautiful.createText(info);
        p.add(Beautiful.CreatScroll(txt));
        Box buttons= Box.createHorizontalBox();
        JButton yes=new JButton("Confirm");
        JButton no=new JButton("Cancel");
        buttons.add(Box.createHorizontalGlue());
        buttons.add(yes);
        buttons.add(Box.createHorizontalGlue());
        buttons.add(no);
        buttons.add(Box.createHorizontalGlue());
        p.add(buttons);
        no.addActionListener((e)->jf.dispose());
        yes.addActionListener((e)-> {
            jf.dispose();
            run.run();
        });

        jf.setMinimumSize(new Dimension(300,200));
        jf.pack();
        jf.setLocationRelativeTo(f);
        jf.setVisible(true);
    }

    public static boolean TF(Window frame) {
        return TF(frame, "Ture or False");
    }

    public static boolean TF(Window frame, String log) {
        boolean value = false;
        int op = JOptionPane.showConfirmDialog(null, log, "Choice", JOptionPane.YES_NO_CANCEL_OPTION);
        if (op != 2 && op != -1) {
            switch (op) {
                case 0:
                    value = true;
                    break;
                case 1:
                    value = false;
                    break;
            }
        }
        return value;
    }
    public static void event(Event.singleEvent e){
        event(e,false);
    }
    public static void event(Event.singleEvent e,boolean isCrash){
        String title=e.title;
        if(title==null){
            title="information";
        }
        JFrame f=new JFrame(title);
        Box jp = Box.createVerticalBox();
        f.setContentPane(jp);
        f.setIconImage(image);
        f.add(new JLabel("Message:"));
        JTextArea txt=Beautiful.createText(e.info);
        JScrollPane js=Beautiful.CreatScroll(txt);

        jp.add(js);
        jp.add(new JLabel("Rank:"+e.getRank()));
        jp.add(new JLabel("Time: "+e.time));
        Box buttons=Box.createHorizontalBox();
        if(isCrash){
            JButton send = new JButton("Send report");
            buttons.add(send);
        }
        JButton close=new JButton("OK");
        close.addActionListener((nmsl)->f.dispose());

        buttons.add(Box.createHorizontalGlue());


        buttons.add(close);
        jp.add(buttons);

        Beautiful.setBorder(jp);
        f.setMinimumSize(new Dimension(400,300));
        f.pack();
        Beautiful.setMid(f);
        //f.setAlwaysOnTop(true);
        f.setVisible(true);

    }
    public static JSplitPane createSplitPane(JComponent left,JComponent right){
        JSplitPane splitPane = new JSplitPane();
        splitPane.setLeftComponent(left);
        splitPane.setRightComponent(right);
        splitPane.setContinuousLayout(true);// 拖动分隔条时连续重绘组件
        splitPane.setOneTouchExpandable(true);// 分隔条上显示快速 折叠/展开 两边组件的小按钮
        splitPane.setDividerSize(5);
        return splitPane;
    }
    public static void floatWindow(Window owner,String content,long time){
        JDialog jf=new JDialog(owner,"");
        //JFrame jf=new JFrame(title);
        jf.setIconImage(Show.getImage());
        jf.setAlwaysOnTop(true);
        Container panel=jf.getContentPane();
        panel.setBackground(Color.orange);
        panel.add(new JLabel(content));
        Beautiful.setBorder((JComponent) panel);
        //jf.setResizable(false);
        jf.setUndecorated(true);
        jf.pack();
        //Beautiful.setMid(jf);
        jf.setLocationRelativeTo(owner);
        jf.setVisible(true);
        Tools.autoCloseWindow(jf,time);
    }
    public static void floatWindow(String title,String content,long time){
        JFrame jf=new JFrame(title);
        //JFrame jf=new JFrame(title);
        jf.setIconImage(Show.getImage());
        jf.setAlwaysOnTop(true);
        Container panel=jf.getContentPane();
        panel.setBackground(Color.orange);
        panel.add(new JLabel(content));
        Beautiful.setBorder((JComponent) panel);
        //jf.setResizable(false);
        jf.setUndecorated(true);
        jf.pack();
        //Beautiful.setMid(jf);
        jf.setLocationRelativeTo(null);
        jf.setVisible(true);
        Tools.autoCloseWindow(jf,time);
    }
    public static void offlineMessage(Window window,String title,String msg){
        JDialog f=new JDialog(window,title);
        Box jp = Box.createVerticalBox();
        f.setContentPane(jp);
        f.setIconImage(image);
        f.add(new JLabel("Message:"));
        JTextArea txt=Beautiful.createText(msg);
        JScrollPane js=Beautiful.CreatScroll(txt);

        jp.add(js);
        jp.add(new JLabel("Time: "+Tools.getTime()));
        Box buttons=Box.createHorizontalBox();
        JButton close=new JButton("OK");
        close.addActionListener((nmsl)->Safe.getInstance().exit(0));

        buttons.add(Box.createHorizontalGlue());
        buttons.add(close);
        jp.add(buttons);

        Beautiful.setBorder(jp);
        f.setMinimumSize(new Dimension(400,300));
        f.pack();
        Beautiful.setMid(f);
        //f.setAlwaysOnTop(true);
        f.setVisible(true);
    }
}