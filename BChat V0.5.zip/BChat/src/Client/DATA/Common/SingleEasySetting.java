package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SingleEasySetting {
    static Event event = Event.getInstance();
    private final String label;
    private final String btn;
    private final Runnable run;
    public static String[] all = {"System look",
            "com.jtattoo.plaf.fast.FastLookAndFeel",
            "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel",
            "javax.swing.plaf.metal.MetalLookAndFeel",
            "com.sun.java.swing.plaf.mac.MacLookAndFeel",
            "com.sun.java.swing.plaf.windows.WindowsLookAndFeel",
            "com.sun.java.swing.plaf.motif.MotifLookAndFeel",
            "com.sun.java.swing.plaf.gtk.GTKLookAndFeel",
            "com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel"};

    public SingleEasySetting(String label, String btn, Runnable run) {
        this.label = label;
        this.btn = btn;
        this.run = run;
    }

    public String getLabel() {
        return label;
    }

    public String getBtn() {
        return btn;
    }

    public Runnable getRun() {
        return run;
    }

    public static SingleEasySetting createSkinChooserSingleEasySetting() {
        return new SingleEasySetting("Change skin", "Choose",createSkinChooser());
    }
    public static Runnable createSkinChooser(){
        return () -> {
            final var ref = new Object() {
                Boolean isShowDemo = false;
            };
            GUIDemo demo=new GUIDemo();
            JFrame f = new JFrame("Choose skin");
            f.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    super.windowClosing(e);
                    demo.dispose();
                    if(GUISetting.saveGUISetting()){
                        Show.floatWindow("Successful", "changes saved", 1000);
                    }
                }
            });

            JList<String> list = new JList<>(all);
            list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            list.addListSelectionListener(e -> {
                if (e.getValueIsAdjusting()) {
                    int index = list.getSelectedIndex();
                    event.add(Event.Track, "Prepare set UI look", all[index]);
                    //System.out.println("index is "+index);
                    try {
                        if (index == 0) {
                            System.out.println("System look");
                            GUISetting.guiSetting.setGUI(UIManager.getSystemLookAndFeelClassName());
                        } else {
                            String look = all[index];
                            System.out.println(look);
                            GUISetting.guiSetting.setGUI(look);
                            event.add(Event.Track, "Successful", "UI look set successful");
                        }
                        if(ref.isShowDemo) {
                            demo.showDemo();
                        }
                        Show.floatWindow(f, "UI look set successful",1000);

                    } catch (Exception theException) {
                        theException.printStackTrace();
                        event.add(Event.Warn, "Set UI failed",theException.toString() , true);
                    }
                }
            });
            Beautiful.setBorder(list);
            f.getContentPane().add(list);
            JButton jb=new JButton("Show Demo");
            jb.addActionListener((e)->{
                if(ref.isShowDemo){
                    jb.setText("Closed");
                    demo.dispose();
                }else {
                    jb.setText("Showed");
                    demo.showDemo();
                }
                ref.isShowDemo =!ref.isShowDemo;
            });
            f.getContentPane().add(jb, BorderLayout.SOUTH);
            f.setIconImage(Show.getImage());
            f.pack();
            f.setResizable(false);
            Beautiful.setMid(f);
            f.setVisible(true);
        };
    }
}
