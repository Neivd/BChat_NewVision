package Client.DATA.Common;

import java.awt.*;

public interface WindowInterface {
    public Window window = null;
}
