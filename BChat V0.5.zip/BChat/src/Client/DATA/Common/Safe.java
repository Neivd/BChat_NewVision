package Client.DATA.Common;

import Client.DATA.Common.Event;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Safe {
    Event event;
    private static final Safe instance=new Safe();
    public static Safe getInstance(){
        return instance;
    }
    private final ArrayList<Runnable>  operationsBeforeClose=new ArrayList<>();
    private Safe(){
        setEvent();
    }
    public void addOperation(Runnable e){
        operationsBeforeClose.add(e);
    }
    private void setEvent(){
        this.event=Event.getInstance();
        this.addOperation(() -> {
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(Tools.linkStr("[log][",event.getType(),"][",Tools.getTimeWithoutColon(),"].txt")));
                for(Event.singleEvent i:event.getAll())
                    out.write(i.toString()+"\n");
                out.close();
                System.out.println("Events saved successfully");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
    public void exit(int s) {
        for(Runnable e:operationsBeforeClose){
            e.run();
        }
        System.exit(s);
    }
}
