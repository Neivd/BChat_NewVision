package Client.DATA.Common;

import java.awt.*;
import java.awt.event.ActionListener;

public class TrayMenuItem {
    MenuItem menuItem;

    public TrayMenuItem(String text, ActionListener action) {
        menuItem = new MenuItem(text);
        menuItem.addActionListener(action);
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }
}
