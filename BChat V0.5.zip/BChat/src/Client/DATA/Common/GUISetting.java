package Client.DATA.Common;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GUISetting {
    public static GUISetting guiSetting;
    private String GUI_now;
    private List<String> AllGUIs;
    public static boolean saveGUISetting(){
        try {
            Tools.writeFile("GUISetting.json",Tools.GSON.toJson(GUISetting.guiSetting));
            return true;
        } catch (IOException ioException) {
            Event.getInstance().add(Event.Error,"Save GUI file failed");
            ioException.printStackTrace();
            return false;
        }
    }
    public void setGUI(String GUI) throws Exception {
        this.GUI_now = GUI;
        Exception e=Beautiful.setUI(GUI);
        if(e !=null){
            throw e;
        }
    }
    public void addGUI(String theGUI){
        AllGUIs.add(theGUI);
    }
    public List<String> getAllGUIs(){
        return AllGUIs;
    }
    public String getGUI() {
        return GUI_now;
    }
    public void resetAll(){
        AllGUIs = new ArrayList<>();
        AllGUIs.addAll(Arrays.asList(SingleEasySetting.all));
        resetGUI_now();
    }
    public void resetGUI_now(){
        GUI_now= UIManager.getSystemLookAndFeelClassName();
    }
    public void setGUI(){
        Beautiful.setUI(getGUI());
    }
}
