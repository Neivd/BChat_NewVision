package Client.DATA;

import java.io.Serializable;

public class Single implements Serializable {
    public Single() {
    }

    public Single(String name, short type) {
        this.type = type;
        this.name = name;
    }

    void setAbout(String s) {
        this.log = s;
    }

    /*    public Object getValue(){
            Object result = null;
            switch (type){
                case SettingList.CHOICE:
                case SettingList.TEXT:
                    result= V;//String
                    break;
                case SettingList.ACCOUNT:
                    result =value;//String[]
                    break;
                case SettingList.BOOLVALUE:
                    result= TF;//boolean
                    break;
            }
            return result;
        }*/
    String name = null;
    short type;
    String[] value = null;
    boolean TF;
    String V = null;
    String log = null;

    static ChoiceBtn makeChoiceBtn(String name) {
        return new ChoiceBtn(name, Setting.CHOICE);
    }

    static TextBtn makeTextBtn(String name) {
        return new TextBtn(name, Setting.TEXT);
    }

    static AccountBtn makeAccountBtn(String name) {
        return new AccountBtn(name, Setting.ACCOUNT);
    }

    static BoolBtn makeBoolBtn(String name) {
        return new BoolBtn(name, Setting.BOOL_VALUE);
    }
}

class ChoiceBtn extends Single {
    public ChoiceBtn(String name, short type) {
        super(name, type);
    }

    String getValue() {
        return V;
    }
}

class TextBtn extends ChoiceBtn {
    public TextBtn(String name, short type) {
        super(name, type);
    }
}

class AccountBtn extends Single {
    public AccountBtn(String name, short type) {
        super(name, type);
    }

    String[] getValue() {
        return value;
    }
}

class BoolBtn extends Single {
    public BoolBtn(String name, short type) {
        super(name, type);
    }

    Boolean getValue() {
        return TF;
    }
}