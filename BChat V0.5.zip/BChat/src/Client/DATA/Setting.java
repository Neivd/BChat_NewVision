package Client.DATA;

import Client.DATA.Common.Beautiful;
import Client.DATA.Common.Event;
import Client.DATA.Common.Show;
import Client.DATA.Common.Tools;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.Serializable;

public class Setting implements Serializable {
    public static final short CHOICE = 0;
    public static final short TEXT = 1;
    public static final short ACCOUNT = 2;
    public static final short BOOL_VALUE = 3;
    public SettingList lst;
    JButton[] Jb;
    WindowFunction jf;
    Event event;

    public void setEvent(Event event){
        this.event=event;
    }
    public Setting(SettingList l,Event event) {
        lst = l;
        jf = new UniversalFrame(lst.head);
        this.event=event;
    }

    public Setting(Window f, SettingList l,Event event) {
        lst = l;
        jf = new UniversalDialog(f, l.head);
        this.event=event;
    }

    public void setCallBack(Runnable sth) {
        //should behind build
        jf.addWindowListener(new WindowAdapter() {
            public void windowClosed(WindowEvent e) {
                sth.run();
            }
        });
    }

    public void build() {

        jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        jf.setLocationRelativeTo(null);
        jf.setResizable(false);
        jf.setIconImage(Show.getImage());

        Box pl = new Box(BoxLayout.PAGE_AXIS);
        event.add(Tools.linkStr("number of single settings",String.valueOf(lst.everyone.size())));
        int many = lst.everyone.size();
        Box[] b = new Box[many];
        Jb = new JButton[many];
        for (int count = 0; count < many; count++) {
            Single s = lst.everyone.get(count);
            b[count] = Box.createHorizontalBox();
            b[count].add(Box.createHorizontalStrut(5));
            b[count].add(new JLabel(s.name + " "));
            b[count].add(Box.createHorizontalGlue());
            switch (s.type) {
                case CHOICE:
                    Jb[count] = new JButton("Change(value_now: " + s.V + ")");
                    Jb[count].addActionListener(new choose(count));
                    b[count].add(Jb[count]);
                    break;
                case TEXT:
                    Jb[count] = new JButton("Change(value_now: " + s.V + ")");
                    Jb[count].addActionListener(new text(count));
                    b[count].add(Jb[count]);
                    break;
                case ACCOUNT:
                    Jb[count] = new JButton("Change(value_now: " + s.value[0] + ")");
                    Jb[count].addActionListener(new accounts(count));
                    b[count].add(Jb[count]);
                    break;
                case BOOL_VALUE:
                    Jb[count] = new JButton("Change(value_now: " + s.TF + ")");
                    Jb[count].addActionListener(new tfv(count));
                    b[count].add(Jb[count]);
                    break;
            }
            b[count].add(Box.createHorizontalStrut(40));
            JButton Jb2 = new JButton("About");
            Jb2.addActionListener(new showInfo(s.log));
            b[count].add(Jb2);
            pl.add(b[count]);
        }


        JScrollPane scrollPane = new JScrollPane(
                pl,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER
        );
        scrollPane.getVerticalScrollBar().setUnitIncrement(20);
        jf.setContentPane(scrollPane);
        jf.setSize(500, 400);
        Beautiful.setMid((Window) jf);
        jf.setVisible(true);

    }

    class Father {
        Single s;
        int num;

        public Father(int i) {
            num = i;
            s = lst.everyone.get(num);
        }
    }

    class choose extends Father implements ActionListener {
        public choose(int i) {
            super(i);
        }

        public void actionPerformed(final ActionEvent e) {
            String op = (String) JOptionPane.showInputDialog(null, s.log,
                    "Choice", JOptionPane.QUESTION_MESSAGE, null, s.value, s.V);
            if (op != null) {
                s.V = op;
            }
            //lst.everyone.set(num,s);
            Jb[num].setText("Change(value_now: " + s.V + ")");
        }
    }

    class text extends Father implements ActionListener {
        public text(int i) {
            super(i);
        }

        public void actionPerformed(final ActionEvent e) {
            String op = JOptionPane.showInputDialog(null, s.log);
            if (op != null) {
                s.V = op;
            }
            //lst.everyone.set(num,s);
            Jb[num].setText("Change(value_now: " + s.V + ")");
        }
    }

    class accounts extends Father implements ActionListener {
        public accounts(int i) {
            super(i);
        }

        public void actionPerformed(final ActionEvent e) {
            AccountWindow acc = new AccountWindow(jf,event);
            acc.build();
            String[] op = acc.inf;
            if (op != null) {
                s.value = op;
            }
            //lst.everyone.set(num,s);
            Jb[num].setText("Change(value_now: " + s.value[0] + ")");
        }
    }

    class tfv extends Father implements ActionListener {
        public tfv(int i) {
            super(i);
        }

        public void actionPerformed(ActionEvent e) {
            int op = JOptionPane.showConfirmDialog(null, s.log, "Choice", JOptionPane.YES_NO_CANCEL_OPTION);
            if (op != 2 && op != -1) {
                switch (op) {
                    case 0:
                        s.TF = true;
                        break;
                    case 1:
                        s.TF = false;
                        break;
                }
            }
            //lst.everyone.set(num,s);
            Jb[num].setText("Change(value_now: " + s.TF + ")");
        }
    }

    static class showInfo implements ActionListener {
        String log;

        public showInfo(String log) {
            this.log = log;
        }

        public void actionPerformed(ActionEvent e) {
            Show.m("Detailed", log);
        }
    }

    public static void main(String[] args) {
        Beautiful.setUIFont();
        Single s1 = new Single();
        s1.name = "title";
        s1.type = 0;
        s1.value = new String[]{"123", "qwe", "a", "122", "q", "qewqwe", "qweqwe", "681238te2y"};
        s1.V = "123";
        s1.log = "just a test";

        Single s2 = new Single();
        s2.name = "title2";
        s2.type = 3;
        s2.V = "1";
        s2.log = "just a test2";

        Single s3 = new Single();
        s3.name = "proxy";
        s3.type = 2;
        s3.value = new String[]{"123", "qwe"};
        s3.log = "just a test3";

        SettingList l = new SettingList();
        l.add(s1);
        l.add(s2);
        l.add(s3);
        for (int i = 0; i < 20; i++) {
            l.add(s1);
        }
        new Setting(l,Event.getInstance()).build();
    }
}