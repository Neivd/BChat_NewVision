package Client.DATA;

import java.io.Serializable;
import java.util.ArrayList;

public class Friend{
    String nickname;
    String UID;
    ArrayList<String> f = new ArrayList<>();
    ArrayList<String> text = new ArrayList<>();
    String dirPath;

    public Friend(String friendID,String nickname) {
        UID = friendID;
        this.nickname=nickname;
        dirPath = "/History" + friendID;
    }

    public void new_msg(String s) {
        text.add(s);
    }
}