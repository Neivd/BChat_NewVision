import Client.DATA.Common.Event;
import Client.DATA.Common.Pcl;
import Client.DATA.Common.Tools;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class KeepConnection implements Runnable{
    Socket socket;
    EachUser user;
    Users users;
    BChatServer.MsgIO tools;
    Event event;
    Map<String,KeepConnection> onlineSockets;
    public KeepConnection(EachUser user, Socket socket, Users users, BChatServer.MsgIO tools){
        this.socket=socket;
        this.user=user;
        this.users=users;
        this.tools=tools;
        this.event=tools.getEvent();
        this.onlineSockets=tools.getOnlineSocket();
        Tools.makeRun(this);
    }
    boolean isGetOutputStream=false;
    PrintWriter pw;
    public void send(String msg) {
        event.add("sending:" + msg);
        try {
            if(!isGetOutputStream) {
                OutputStream os = socket.getOutputStream();//字节输出流
                pw = new PrintWriter(os);//将输出流包装为打印流}
                isGetOutputStream=true;
            }
            pw.write(msg);
            pw.write(Pcl.Stop_Char_String);
            pw.flush();
            //socket.shutdownOutput();//关闭输出流
            //Thread.sleep(20);

        } catch (IOException e) {
            event.add(Event.Error,"Send failed",e.toString());
            e.printStackTrace();
        }
    }
    void sendList(String[] info) {
        StringBuilder content = new StringBuilder();
        for (int i = 0; i < info.length - 1; i++) {
            content.append(info[i]).append(Pcl.Split_Char);
        }
        content.append(info[info.length - 1]);
        send(content.toString());
    }
    void sendFrdMsg(String str){
        sendList(new String[]{Pcl.toClient.Friend_Message,this.user.UID,str});
    }
    void forceOffline(){
        send(Pcl.toClient.Force_Offline);
        try {
            close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    void close() throws IOException {
        isGoingOn=false;
        pw.close();
        socket.close();
    }
    boolean isGoingOn=true;
    @Override
    public void run() {
        event.add(user.UID+" thead started");
        int a;
        BufferedReader in= null;
        try {
            in = new BufferedReader(new InputStreamReader(
                    socket.getInputStream(), StandardCharsets.UTF_8));
        } catch (IOException e) {
            event.add(Event.Fatal,"Can't get input",e.toString());
            e.printStackTrace();
        }
        StringBuilder sb=new StringBuilder();
        while (true){
            if(!isGoingOn){
                break;
            }
            sb.delete(0, sb.length());
            try {
                while ((a = in.read()) != 4) {
                    //event.add(a);
                    //event.add("in while");
                    if (a == -1) {
                        //this socket is disconnect
                        event.add(user.UID+"if offline at");
                        break;
                    }
                    sb.append((char) a);
                }
            } catch (IOException e) {
                event.add(Event.Fatal,"Can't get message from server",e.toString());
                e.printStackTrace();
            }
            String[] inBox=sb.toString().split(Pcl.Stop_Char_String);
            switch (inBox[0]){
                case Pcl.toServer.Get_Friend:
                    sendList(users.getFriendWithWarppedInfo(this.user.UID));
                    event.add("Sending friends info for"+user.UID);
                    break;
                case Pcl.toServer.Send_Msg:
                    if(onlineSockets.containsKey(inBox[1])){
                        try {
                            onlineSockets.get(inBox[1]).sendFrdMsg(inBox[2]);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case Pcl.toServer.Use_Json:
                    break;
                case Pcl.toServer.Add_New_Friend:
                    users.addFriend(user,inBox[2]);
                    break;
            }
        }


    }
}
