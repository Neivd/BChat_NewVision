package Client.DATA;

import Client.DATA.Common.Tools;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class TakeScreenshotDemo {

    public static void main(String[] args) throws Exception {
        // 保存截取的图片
        ImageIO.write(Tools.takeScreenshots(), "PNG", new File(Tools.linkStr("Capture at",Tools.getTimeWithoutColon(),".png")));
    }

}