package Client.DATA;


import java.net.Proxy;

public interface ProxyPcl {
    void setProxy(Proxy proxy);
}
