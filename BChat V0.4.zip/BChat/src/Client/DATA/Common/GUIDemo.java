package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class GUIDemo {
    private JFrame jf;
    private JPanel jPanel;

    public static void main(String[] args) {
        new GUIDemo();
    }
    Box box;
    public GUIDemo(){
        //jf.setVisible(true);
    }
    void build(){
        jf=new JFrame("Demo");
        jPanel=new JPanel();
        jPanel.add(new JLabel("Demo label"));
        jPanel.add(new JButton("Demo button"));
        jPanel.add(Beautiful.CreatScroll(Beautiful.createText("Demo text&scroll")));
        jPanel.add(new JCheckBox("Demo"));

        box=Box.createVerticalBox();
        box.add(jPanel);
        box.add(new JColorChooser());
        jf.setContentPane(box);
        Beautiful.setBorder(box);
        jf.pack();
        jf.setLocationRelativeTo(null);
        jf.setVisible(true);
    }
    public void showDemo(){
        if(jf!=null){
            dispose();
        }
        build();
    }
    public void dispose(){
        if(jf==null){
            return;
        }
        jf.dispose();
    }
}
