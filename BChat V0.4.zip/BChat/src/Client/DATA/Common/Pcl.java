package Client.DATA.Common;

public class Pcl {
    //this is for client
    public static class toClient{

        public final static String NAME_OR_PASSWD_ERROR = "0";
        public final static String NAME_AND_PASSWD_RIGHT = "1";
        public final static String Account_Already_Online = "2";
        public final static String SIGNUP_SUCC = "4";
        //up is only number
        //down is send with args
        public final static String Send_Friends_Info ="0";
        public final static String Friend_Message ="1";
        public final static String Sign_Up_Failure ="2";
        public final static String Get_Other_User_Info="3";
        public final static String Important_Info="4";
        public final static String Your_Friend_Del_You="0";
        public final static String Other_Important_Message="1";
        public final static String Use_Json="5";

    }
    public static class toServer{
        public final static String Verify_Account="0";
        public final static String Send_Msg="1";
        public final static String Get_Friend="2";
        public final static String Use_Json="3";
        public final static String Apply_New_Account="4";
        public final static String Get_Other_User="6";
        public final static String Add_New_Friend ="7";
        public final static String Delete_Friend="8";



    }
    public final static String Split_Char = String.valueOf((char)30);
    public final static String Stop_Char_String =String.valueOf((char)4);
    public final static char Stop_Char =(char)4;
    public final static String Child_Spilt_Chat_String=String.valueOf((char)25);
}
