package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class ButtonItem {
    JButton jb;
    public ButtonItem(String name, ActionListener actionListener){
        jb=new JButton(name);
        jb.addActionListener(actionListener);
    }
    public JButton getButton(){
        return jb;
    }
}
