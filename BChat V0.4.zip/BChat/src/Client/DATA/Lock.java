package Client.DATA;

import java.math.BigInteger;

public class Lock {
    private long key;

    public Lock(long key) {
        this.key = key;
    }

    public String en(BigInteger num) {

        return "";
    }
}
