package Client.DATA;

import Client.DATA.Common.Event;
import Client.DATA.Common.Pcl;
import static Client.DATA.Common.Pcl.toClient;
import Client.DATA.Common.Safe;
import Client.DATA.Common.Show;

import java.io.*;
import java.net.Proxy;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

public class Net implements Runnable {
    Safe safe=Safe.getInstance();
    MUI mainUI;
    Socket socket;
    String IP;
    int com;
    String splitChar = Pcl.Split_Char;
    String inBox;
    String myID;
    String myName;
    String[] loginInfo;
    boolean isProxy = false;
    sendMsg msgIO = new sendMsg();
    //boolean ifConn=false;
    boolean status = false;
    //Net self=this;
    Proxy myProxy;
    boolean isBuildGUI = false;
    ArrayList<Friend> frdArray = new ArrayList<>();
    Event event;
    public static void main(String[] args) {
    }

    public Net(String IP, int com,Event event) {
        this.event=event;
        this.IP = IP;
        this.com = com;
/*        try {
            socket = new Socket(IP,com);
            //socket.setKeepAlive(true);
            //ifConn=true;
        }catch (IOException e){
            Show.m("Error","Network Error");
            e.printStackTrace();
            Client.DATA.Common.Safe.exit(0);
        }*/
    }

    void recv() throws IOException {
        InputStream is = socket.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        ArrayList<String[]> inBoxMsg = new ArrayList<>();
        while (true) {
            int a;
            sb.delete(0, sb.length());
            while ((a = in.read()) != 4) {
                //event.add(a);
                //event.add("in while");
                if (a == -1) {
                    event.add("Can not get information from server");
                    Show.m("WARN", "Can not connect the server");
                    safe.exit(-2);
                    break;
                }
                sb.append((char) a);
            }
            inBox=sb.toString();
/*            sb.delete(0, sb.length());
            while ((a=in.readChar()) != (char)4){
                sb.append(a);
            }*/
            //inBox = in.readUTF();
            event.add(inBox);
            //socket.shutdownInput();
            //is.close();
            //in.close();
            switch (inBox) {
                case Pcl.toClient.NAME_OR_PASSWD_ERROR:
                    if (!status) {
                        event.add(Event.Error,"close socket");
                        socket.shutdownInput();
                        socket.shutdownOutput();
                        socket.close();
                        Show.m("ERROR", "Passwd or account Error");
                        return;
                    }
                    Show.m("ERROR", "Passwd or account Error");
                    break;
                case toClient.NAME_AND_PASSWD_RIGHT:
                    status = true;
                    event.add(Event.Track,"Login succ");
                    send("2");

                    break;
                case toClient.Account_Already_Online:
                    if (!status) {
                        socket.close();
                    }
                    event.add(Event.Track,"Account has login already");
                    Show.m("ERROR", "Your account is already online");
                    break;
                case "3":

                    break;
                case toClient.SIGNUP_SUCC:
                    socket.close();
                    event.add(Event.Track,"succ", "apply account success",true);
                    return;
                default://mean with other args
                    event.add("in default method");
                    String[] list = inBox.split(Pcl.Split_Char);
                    event.add(list[0]);
                    switch (list[0]) {
                        case toClient.Send_Friends_Info:
                            event.add("Getting Friends");
                            String[] frds = Arrays.copyOfRange(list, 1, list.length);//need splitting
                            if (frds[0].equals(String.valueOf((char) 26))) {
                                //frds = new String[]{};//if it's (char)26,mean no Friend
                                continue;
                            }
                            for(String i:frds){
                                String[] eachFriend=i.split(String.valueOf((char)25));
                                frdArray.add(new Friend(eachFriend[0],eachFriend[1]));
                            }
                            event.add(Arrays.toString(frds));
                            if (isBuildGUI) {
                                mainUI.closeAll();
                            }
                            makeRun(new BuildGUI());
                            break;
                        case toClient.Friend_Message:
                            event.add(Arrays.toString(list));
                            while (mainUI == null) {//make sure MainUI has been created already
                                try {
                                    Thread.sleep(10);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            while (!mainUI.ifCreated) {
                                try {
                                    Thread.sleep(10);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            try {
                                mainUI.addMessage(list);
                                for (String[] i : inBoxMsg) {
                                    mainUI.addMessage(i);
                                }
                                inBoxMsg.clear();
                                break;
                            } catch (AddItemException e) {
                                e.printStackTrace();
                                event.add("try to solve problem");
                                inBoxMsg.add(list);
                                msgIO.reFreshFriends();
                            }

                            break;
                        case toClient.Sign_Up_Failure:
                            Show.m("Sign up failed", list[1]);
                            socket.close();
                            return;//close this function
                        case toClient.Get_Other_User_Info:
                            mainUI.addFriendPane.update(Arrays.copyOfRange(list, 1, list.length));
                            break;
                        case toClient.Important_Info:
                            switch (list[1]) {
                                case toClient.Your_Friend_Del_You:
                                    msgIO.reFreshFriends();
                                    event.add(Event.Info,"Warning", "Error,your friend has deleted you already",true);
                                    break;
                                case toClient.Other_Important_Message:
                                    event.add(Event.Info,"INFO", list[2],true);
                            }
                    }
            }
            inBox = null;
        }
    }

    public void run() {

        event.setDebug(true);

        int i = 0;
        while (i < 10) {
            try {
                new Login().run();//load Login UI and send info
                i = 0;
                recv();
            } catch (IOException e) {
                i++;
                connSocket();
                event.add(Event.Fatal,"Error","Network Error");
            }
        }
        event.add(Event.Fatal,"Error", "Bad Network");
    }

    public static void makeRun(Runnable thing) {
        Thread newThread = new Thread(thing);
        newThread.start();
    }

    PrintWriter pw;
    boolean isGetOutput = false;

    public void send(String msg) {
        event.add("sending:" + msg);
        try {
            if (!isGetOutput) {
                OutputStream os = socket.getOutputStream();//字节输出流
                pw = new PrintWriter(os);//将输出流包装为打印流
                isGetOutput = true;
            }
            pw.write(Pcl.Stop_Char_String);
            //pw.writeUTF(String.valueOf((char)4));
            //pw.write((char)4);
            pw.flush();
            //socket.shutdownOutput();//关闭输出流
            //Thread.sleep(20);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void sendList(String[] info) {
        StringBuilder content = new StringBuilder();
        for (int i = 0; i < info.length - 1; i++) {
            content.append(info[i]).append(splitChar);
        }
        content.append(info[info.length - 1]);
        send(content.toString());
    }

    void verify(String[] info) {
        connSocket();
        String msg = buildString(new String[]{Pcl.toServer.Verify_Account,
                splitChar,info[0] , splitChar , info[1]});
        send(msg);
        //return status;
    }
    StringBuilder builder=new StringBuilder();
    String buildString(String[] str){
        builder.replace(0,builder.length(),"");
        for(String s:str){
            builder.append(s);
        }
        return  builder.toString();
    }
    class Login implements Runnable {
        public void run() {
            AccountWindow acc = new AccountWindow(event);
            acc.setSignUp(true);
            acc.setProxy(true);
            acc.setQuit(true);
            acc.setConn(msgIO);
            acc.setTitle("BChat: Login");
            acc.setProsyCallBack(new proxySetter());
            acc.build();
            loginInfo = acc.get();
            if (loginInfo == null) {
                loginInfo = new String[]{"", ""};
            } else
                myID = loginInfo[0];
            verify(loginInfo);
        }
    }

    class BuildGUI implements Runnable {
        public void run() {
            mainUI = new MUI(myID,myName);
            mainUI.msgIO = msgIO;

            Friends friends = new Friends(myID);
            friends.addAllFrd(frdArray);
            mainUI.friends = friends;
            isBuildGUI = true;
            mainUI.build();
        }
    }

    class proxySetter implements ProxyPcl {

        @Override
        public void setProxy(Proxy proxy) {
            isProxy = true;
            myProxy = proxy;
        }
    }

    class sendMsg {

        Safe getSafeExit(){
            return safe;
        }
        void sendData(String frdName, String s) {
            String msg = "1" + splitChar + frdName + splitChar + s;
            send(msg);
        }

        void connAndSend(String[] s) {
            connSocket();
            sendList(s);
        }

        void recvMsg() {
            try {
                recv();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        void sendListData(String... strings){
            sendList(strings);
        }

        void reFreshFriends() {
            send(Pcl.toServer.Get_Friend);
        }

        void sendData(String msg) {
            send(msg);
        }
        Event getEvent(){
            return event;
        }
    }

    void connSocket() {
        try {
            if (isProxy) {
                socket = new Socket(myProxy);//there are some problems
            } else {
                socket = new Socket(IP, com);
            }
        } catch (IOException e) {
            event.add(e.toString());
            e.printStackTrace();
            safe.exit(-2);
        }
    }

}
