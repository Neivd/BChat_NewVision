package Client.DATA;


import Client.DATA.Common.GUISetting;
import com.google.gson.Gson;

public class test2 {
    public static void main(String[] args) {
        new test2().go();
    }
    void go(){
        GUISetting guiSetting=new GUISetting();
        guiSetting.resetAll();
        guiSetting.setGUI("test");
        Gson gson=new Gson();
        String jsonObj=gson.toJson(guiSetting);
        System.out.println(jsonObj);
        GUISetting newGUISetting=gson.fromJson(jsonObj,guiSetting.getClass());
        System.out.println(newGUISetting.getAllGUIs());
    }
}
