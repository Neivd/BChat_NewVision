package Client.DATA;

import Client.DATA.Common.Beautiful;
import Client.DATA.Common.Event;
import Client.DATA.Common.Show;
import Client.DATA.Common.Pcl.toServer;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class AddFriend {
    Net.sendMsg msgio;
    JFrame jf;
    JTextField searchField = new JTextField();
    JPanel otherUser = new JPanel();
    String myID = "SB";
    Event event;

    public AddFriend(Net.sendMsg msgIO, String ID, Event event) {
        this.msgio = msgIO;
        this.myID = ID;
        this.event=event;
        this.build();
    }
    void setEvent(Event event){
        this.event=event;
    }

    public AddFriend() {
        System.out.println("Warning,this mode is danger");

    }

    public static void main(String[] args) {
        Beautiful.setUIFont();

        AddFriend a = new AddFriend();
        a.setEvent(Event.getInstance());
        a.build();
        a.setVisible(true);
        String[] friends = new String[100];
        for (int i = 0; i < friends.length; i++) {
            friends[i] = String.valueOf(i);
        }
        a.update(friends);

    }

    public void build() {
        jf = new JFrame("Add Friend For " + myID);
        Box searchBar = Box.createHorizontalBox();
        Beautiful.setBorder(searchBar);
        searchBar.add(new JLabel("Find:"));
        searchBar.add(searchField);
        JButton searchBtn = new JButton("Search");
        searchBtn.addActionListener(new sendInfo());
        searchField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    new sendInfo().actionPerformed(new ActionEvent(0, 0, null));
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
        searchBar.add(searchBtn);
        jf.add(searchBar, BorderLayout.NORTH);
        jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        
        /*JScrollPane otherUserScrollPane=new JScrollPane(otherUser,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);*/
        otherUser.setBorder(new EmptyBorder(0, 10, 10, 10));
        jf.setMinimumSize(new Dimension(500, 500));
        jf.setIconImage(Show.getImage());
        jf.add(otherUser, BorderLayout.CENTER);
        jf.setSize(800, 600);
        Beautiful.setMid(jf);
        //jf.setVisible(true);
    }

    public void setVisible(boolean value) {
        if (jf.isShowing() != value) {
            jf.setVisible(value);
        }
    }

    public void update(String[] users) {
        for (String i : users) {
            JButton temp = new JButton(i);
            otherUser.add(temp);
            temp.addActionListener(new eachBtn(i));
        }
        otherUser.updateUI();
    }

    class eachBtn implements ActionListener {
        String nickName;
        String UID;

        public eachBtn(String name) {
            this.UID = name;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            Show.confirm(jf,"Add new Friend","Are you sure add: "+ UID,()->{
                event.add("apply for adding " + UID);
                Show.confirm(jf,"Self introduce","I'm "+myID, (str)->{
                    msgio.sendListData(toServer.Add_New_Friend, UID,str);
                });
            });
                //msgio.reFreshFriends();
        }
    }

    class sendInfo implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            otherUser.removeAll();
            //Show.m(jf,"title","!");
            if (searchField.getText().equals("")) {
                msgio.sendListData(toServer.Get_Other_User);
            } else {
                msgio.sendListData(toServer.Get_Other_User, searchField.getText());
            }
        }
    }
}
