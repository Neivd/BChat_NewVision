package Client.DATA;

import java.io.Serializable;
import java.util.ArrayList;

public class Friend implements Serializable {
    String nickname;
    String UID;
    ArrayList<String> f = new ArrayList<>();
    ArrayList<String> text = new ArrayList<>();
    int f_now;//the address of File in list
    String dirPath;

    public Friend(String friendID,String nickname) {
        UID = friendID;
        this.nickname=nickname;
        dirPath = "/History" + friendID;
    }

    public boolean older() {
        if (f_now < f.size()) {
            f_now++;
            text = (ArrayList<String>) BChatFile.read(f.get(f_now));
            return true;
        }
        return false;
    }

    public boolean earlier() {
        if (f_now > f.size()) {
            f_now--;
            text = (ArrayList<String>) BChatFile.read(f.get(f_now));
            return true;
        }
        return false;
    }

    public void new_msg(String s) {
        text.add(s);
    }
}