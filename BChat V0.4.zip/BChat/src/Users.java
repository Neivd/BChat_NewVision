import Client.DATA.Common.Pcl;

import java.util.HashMap;
import java.util.Map;

public class Users {
    Map<String,EachUser> all;
    long key;
    public Users(long key){
        this.key=key;
    }
    boolean addNewUser(String UID, String nickName, String passwd){
        if(all.containsKey(UID)) {
            return false;
        }
        all.put(UID,new EachUser(UID, nickName,passwd));
        return true;
    }
    boolean delUser(String UID){
        EachUser u=all.remove(UID);
        return u != null;
    }
    void makeTestUser(){
        all=new HashMap<>();
        addNewUser("57u","Nonetheless","123");
        addNewUser("sb","Noneless","123");
        addNewUser("test","justATest","123");
    }
    void addFriend(String UID1,String UID2){
        all.get(UID1).addFriend(all.get(UID2));
    }
    void delFriend(String UID1,String UID2){
        all.get(UID1).delFriend(all.get(UID2));
    }
    void changeName(String UID,String newName){
        all.get(UID).changeName(newName);
    }
    void changePasswd(String UID,String newPasswd){
        all.get(UID).changePasswd(newPasswd);
    }
    String[] getFriendWithWarppedInfo(String UID){
        EachUser thisUser=all.get(UID);
        String[] info=new String[thisUser.friend.size()+1];
        info[0]= Pcl.toClient.Send_Friends_Info;
        int index=1;
        for (String i:thisUser.friend){
            info[index]=i+Pcl.Child_Spilt_Chat_String+all.get(i).nickname;
            index++;
        }
        return info;
    }
    boolean Login(String UID,String passwd){
        EachUser u=all.get(UID);
        if(u==null){
            return false;
        }
        return u.getPasswd().equals(passwd);
    }

}
