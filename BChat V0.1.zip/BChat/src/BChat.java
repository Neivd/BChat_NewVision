import DATA.pakages.*;

import javax.swing.JFrame;
public class BChat {
    Net net;
    public static void main(String[] args){
        new BChat().build();
    }
    private void build(){
        setting.setUIFont();
        String IP="127.0.0.1";
        int com=8001;
        net=new Net(IP,com);
        net.run();
    }
}