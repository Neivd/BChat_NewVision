package DATA.pakages;

import java.io.Serializable;
public class single implements Serializable{
    String text=null;
    short type;
    String[] value=null; 
    Integer TF=null;
    String V=null;
    String log=null;
}