package DATA.pakages;

import javax.swing.*;

public class test {
    private JPanel panel1;
    private JPasswordField passwordField1;
    private JComboBox comboBox1;
    private JSlider slider1;
}
