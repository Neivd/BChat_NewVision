import pickle
f=open('user','wb')
pickle.dump({},f)
f.close()
