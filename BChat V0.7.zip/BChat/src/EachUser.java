import java.io.Serializable;
import java.util.ArrayList;

public class EachUser implements Serializable {
    String UID;
    String nickname;
    String passwd;
    ArrayList<String> friend=new ArrayList<>();

    public EachUser(String UID, String name, String passwd) {
        this.UID= UID;
        this.passwd=passwd;
        this.nickname =name;
    }
    String getUID(){
        return UID;
    }
    String getNickname(){
        return nickname;
    }
    void addFriend(EachUser other){
        friend.add(other.getUID());
        other.friend.add(UID);
    }
    void delFriend(EachUser other){
        friend.remove(other.UID);
        other.friend.remove(UID);
    }
    void changePasswd(String newPasswd){
        this.passwd=newPasswd;
    }
    void changeName(String newName){
        this.nickname =newName;
    }
    String getPasswd(){
        return passwd;
    }
}
