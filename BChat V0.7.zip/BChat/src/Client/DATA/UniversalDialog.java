package Client.DATA;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;

public class UniversalDialog extends JDialog implements WindowFunction {
    public UniversalDialog(JDialog jf, String account, boolean b) {
        super(jf, account, b);
    }

    public void add(JPanel panel) {
        super.add(panel);
    }

    public void addWindowListener(WindowAdapter windowAdapter) {
        super.addWindowListener(windowAdapter);
    }

    public void setLocationRelativeTo(Object o) {
        super.setLocationRelativeTo((Component) o);
    }


    public void setLocationRelativeTo(Component component) {
        super.setLocationRelativeTo(component);
    }

    public void setContentPane(JScrollPane scrollPane) {
        super.setContentPane(scrollPane);
    }

    public UniversalDialog() {
        super();
    }

    public UniversalDialog(Frame owner) {
        super(owner);
    }

    public UniversalDialog(Frame owner, boolean modal) {
        super(owner, modal);
    }

    public UniversalDialog(Frame owner, String title) {
        super(owner, title);
    }

    public UniversalDialog(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
    }

    public UniversalDialog(Frame owner, String title, boolean modal, GraphicsConfiguration gc) {
        super(owner, title, modal, gc);
    }

    public UniversalDialog(Dialog owner) {
        super(owner);
    }

    public UniversalDialog(Dialog owner, boolean modal) {
        super(owner, modal);
    }

    public UniversalDialog(Dialog owner, String title) {
        super(owner, title);
    }

    public UniversalDialog(Dialog owner, String title, boolean modal) {
        super(owner, title, modal);
    }

    public UniversalDialog(Dialog owner, String title, boolean modal, GraphicsConfiguration gc) {
        super(owner, title, modal, gc);
    }

    public UniversalDialog(Window owner) {
        super(owner);
    }

    public UniversalDialog(Window owner, ModalityType modalityType) {
        super(owner, modalityType);
    }

    public UniversalDialog(Window owner, String title) {
        super(owner, title);
    }

    public UniversalDialog(Window owner, String title, ModalityType modalityType) {
        super(owner, title, modalityType);
    }

    public UniversalDialog(Window owner, String title, ModalityType modalityType, GraphicsConfiguration gc) {
        super(owner, title, modalityType, gc);
    }
}
