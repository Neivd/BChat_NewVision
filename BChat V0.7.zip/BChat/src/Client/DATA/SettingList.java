package Client.DATA;

import java.io.Serializable;
import java.util.ArrayList;

public class SettingList implements Serializable {

    public String head = "Setting";
    public ArrayList<Single> everyone = new ArrayList<>();

    public SettingList() {
    }

    public SettingList(String s) {
        head = s;
    }

    public SettingList(String s, ArrayList<Single> i) {
        this.head = s;
        this.everyone = i;
    }

    public void add(Single i) {
        this.everyone.add(i);
    }

    public void setTitle(String t) {
        this.head = t;
    }
}
