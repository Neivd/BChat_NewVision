package Client.DATA;

import Client.DATA.Common.*;
import Client.DATA.Common.Event;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class MUI {
    Net.sendMsg msgIO;
    Friends friends;
    Box Pa;
    JPanel Pb;
    Box Me;
    Box FriendTab;
    Box GroupTab;
    JPanel talk;
    JTextArea txt = new JTextArea();
    JTextField sendMsg = new JTextField();
    JPanel[] mePane = new JPanel[4];
    JFrame jf;
    Friend currentFriend;
    boolean face = false;
    String myID;
    AddFriend addFriendPane;
    boolean isCreated = false;
    TrayIcon trayicon;
    SystemTray systemTray;
    String myName;

    JFrame getJf(){
        return jf;
    }
    void addMessage(String[] list) throws AddItemException {
        //this func is for add msg to the window
        String msg = "Recv: " + list[2] + "\n";
        if (currentFriend != null) {
            if (currentFriend.UID.equals(list[1])) {
                txt.append(msg);
            }
        }
        try {
            (friends.nameMap.get(list[1])).text.add(msg);
        } catch (NullPointerException e) {
            event.add(Event.Warn,"can't find this friend",Tools.linkStr("Can't find ",list[1]));
            throw new AddItemException("no such friend");
        }
    }
    void addMessage(String msg) {
        if (currentFriend != null) {
            txt.append(msg);
        }
        currentFriend.text.add(msg);
    }

    public static void main(String[] args) {
        Beautiful.setUIFont();
        Friend pig = new Friend("250","sb");
        ArrayList<String> temp = new ArrayList<>();
        temp.add("pig");
        pig.text = temp;
        Friends l = new Friends("1");
        l.addFrd(pig);
        MUI m = new MUI("1","sb");
        m.friends = l;
        m.build();
    }
    Event event=Event.getInstance();
    MUI(String myID,String myName) {
        this.myID = myID;
        this.myName=myName;
    }

    void closeAll() {
        jf.dispose();
        systemTray.remove(trayicon);
    }
    class delFrd{
        String UID;
        public delFrd(String UID){
            this.UID=UID;

        }
        public void del(){
            Show.confirm(jf, "Confirm operation",
                    "Are you sure delete this friend: " + UID, () -> {
                        msgIO.sendListData(Pcl.toServer.Delete_Friend, UID);
                        msgIO.reFreshFriends();
                    });
        }
    }
    Safe safe;
    void build() {
        safe=Safe.getInstance();
        jf = new JFrame("BChat: " + myID);
        jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        jf.setSize(800, 600);
        jf.setIconImage(Show.getImage());
        jf.setLocationRelativeTo(null);
        jf.setMinimumSize(new Dimension(500, 500));


        Pa = Box.createVerticalBox();
        Pb = new JPanel(new BorderLayout());
        talk = new JPanel(new BorderLayout());

        JSplitPane splitPane = Show.createSplitPane(Pa,Pb);
        jf.setContentPane(splitPane);


        final JTabbedPane tabbedPane = new JTabbedPane();
        Pa.add(tabbedPane);

        FriendTab = Box.createVerticalBox();
        GroupTab = Box.createVerticalBox();
        Me = Box.createVerticalBox();

        ButtonItem[] MeTableBtn ={new ButtonItem("About me",new MeBtnPress(0)),
                            new ButtonItem("Edit info",new MeBtnPress(1)),
                            new ButtonItem("Setting",new bootSetting()),
                            new ButtonItem("Set skin",(e)-> Show.createSkinChooser().run()),
                            new ButtonItem("About",new MeBtnPress(3))};

        for (int i = 0; i < mePane.length; i++) {
            mePane[i] = new JPanel();
        }
        mePane[0].add(new JLabel("About Me"));
        mePane[1].add(new JLabel("Edit page"));
        mePane[3].add(new JLabel(Show.getIco()), BorderLayout.WEST);
        mePane[3].add(new JLabel("BChat version:1.0"));

        for (ButtonItem i : MeTableBtn) {
            Me.add(i.getButton());
        }
        JButton addFrdBtn = new JButton("Add Friend");
        Me.add(addFrdBtn);
        addFriendPane = new AddFriend(msgIO, myID,event);
        addFrdBtn.addActionListener(e -> addFriendPane.setVisible(true));

        tabbedPane.addTab("Friends", FriendTab);
        tabbedPane.addTab("Groups", GroupTab);
        tabbedPane.addTab("Me", Me);


        for (Friend i : friends.nameMap.values()) {
            JButton tb = new JButton(i.nickname);
            tb.addActionListener(new frdBtnPress(i));
            FriendTab.add(tb);
        }


        txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        txt.setFont(new Font("Dialog", Font.PLAIN, 16));
        ((DefaultCaret) txt.getCaret()).setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);//make the text area always scroll down
        //为txt设计右键菜单
        JMenuItem[] txtMenuItem = new JMenuItem[2];
        txtMenuItem[0] = new JMenuItem("Clear");
        txtMenuItem[0].addActionListener(e -> txt.setText(""));
        txtMenuItem[1] = new JMenuItem("delete this friend");
        txtMenuItem[1].addActionListener(e -> new delFrd(currentFriend.UID).del());
        JPopupMenu txtPopMenu = new JPopupMenu();
        for (JMenuItem i : txtMenuItem) {
            txtPopMenu.add(i);
        }
        txt.add(txtPopMenu);
        txt.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                // TODO Auto-generated method stub
                super.mouseReleased(e);
                // 如果释放的是鼠标右键
                if (e.isPopupTrigger()) {
                    txtPopMenu.show(txt, e.getX(), e.getY());
                }
            }
        });

        sendMsg.setFont(new Font("Dialog", Font.PLAIN, 16));
        sendMsg.addKeyListener(new enterPressed());
        talk.add(new JScrollPane(txt,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER));
        talk.add(sendMsg, BorderLayout.SOUTH);
        Pb.add(new JLabel("welcome to BChat"), BorderLayout.NORTH);

        if (SystemTray.isSupported()) {        //make system tray
            TrayMenuItem[] trayMenuItems = new TrayMenuItem[]{
                    new TrayMenuItem("Quit", e -> safe.exit(0)),
                    new TrayMenuItem("Hide/show", e -> jf.setVisible(!jf.isShowing())),
                    new TrayMenuItem("Setting", e -> new bootSetting().actionPerformed(new ActionEvent("", 0, ""))),
                    new TrayMenuItem("Add friend", e -> addFriendPane.setVisible(true)),
                    new TrayMenuItem("Refresh", e -> msgIO.reFreshFriends())
            };

            PopupMenu trayMenu = new PopupMenu();
            for (int i= trayMenuItems.length-1;i>=0;i--) {
                trayMenu.add(trayMenuItems[i].getMenuItem());
            }
            trayicon = new TrayIcon(Show.getImage(), "BChat:" + myID, trayMenu);
            trayicon.setImageAutoSize(true);
            trayicon.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                switch (e.getButton()) {
                                    case MouseEvent.BUTTON1: {
                                        event.add("托盘图标被鼠标左键被点击");
                                        if (!jf.isShowing()) {
                                            jf.setVisible(true);
                                        }
                                        break;
                                    }
                                    case MouseEvent.BUTTON2: {
                                        event.add("托盘图标被鼠标中键被点击");
                                        break;
                                    }
                                    case MouseEvent.BUTTON3: {
                            event.add("托盘图标被鼠标右键被点击");
                            break;
                        }
                    }
                }
            });
            try {
                systemTray = SystemTray.getSystemTray();
                systemTray.add(trayicon);//creat system tray
            } catch (AWTException e) {
                e.printStackTrace();
            }
        }

        jf.setVisible(true);
        isCreated = true;
    }

    class enterPressed implements KeyListener {
        public void keyReleased(final KeyEvent e) {
        }

        public void keyTyped(final KeyEvent e) {
        }

        public void keyPressed(final KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                String msg=sendMsg.getText();
                if(msg.equals("")){
                    Show.floatWindow(jf,"Message can't be empty",1000);
                    return;
                }
                String message = Tools.linkStr("Me: " , msg , "\n");
                addMessage(message);
                sendMsg.setText("");
                msgIO.sendData(currentFriend.UID, msg);

            }
        }
    }

    static class bootSetting implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Setting.main(new String[]{""});
        }
    }

    class MeBtnPress implements ActionListener {
        int num;

        public MeBtnPress(int n) {
            num = n;
        }

        public void actionPerformed(ActionEvent e) {
            face = false;
            Pb.removeAll();
            Pb.add(mePane[num]);
            Pb.updateUI();

        }
    }

    class frdBtnPress implements ActionListener {
        Friend thisFriend;

        public frdBtnPress(Friend n) {
            thisFriend = n;
        }

        public void actionPerformed(ActionEvent e) {
            currentFriend = thisFriend;
            if (!face) {
                Pb.removeAll();
                Pb.add(talk);
                setTxtMsg();
                face = false;//mean stay talk interface
            } else {
                setTxtMsg();
            }
        }

        void setTxtMsg() {
            txt.setText("");
            for (String i : thisFriend.text) {
                txt.append(i);
            }
            Pb.updateUI();
        }
    }
}
