package Client.DATA;

import Client.DATA.Common.Beautiful;
import Client.DATA.Common.Event;
import Client.DATA.Common.SetProxyGUI;
import Client.DATA.Common.Show;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.InetSocketAddress;
import java.net.Proxy;

public class AccountWindow {
    JPasswordField passwordText;
    JTextField userText;
    String[] inf;
    WindowFunction dialog;
    Net.sendMsg conn;
    Net.proxySetter proxySetter;
    boolean isCanSignUp = false;
    boolean isCanProxy = false;
    boolean loginBtnPressed = false;
    boolean isQuit = false;
    Event event;

    public void setConn(Net.sendMsg conn) {
        this.conn = conn;
    }

    public void setTitle(String title) {
        dialog.setTitle(title);
    }

    public AccountWindow(WindowFunction jf,Event event) {
        this.event=event;
        if (jf instanceof Dialog) {
            dialog = new UniversalDialog((Dialog) jf, "Account", true);
        } else {
            dialog = new UniversalDialog((Frame) jf, "Account", true);
        }
    }

    public AccountWindow(Window jf, boolean modal,Event event) {
        dialog = new UniversalDialog((Dialog) jf, modal);
        this.event=event;
    }

    public AccountWindow(Event event) {
        dialog = new UniversalFrame("Account");
        this.event=event;
    }

    public void setSignUp(boolean value) {
        isCanSignUp = value;
    }

    public void setProxy(boolean value) {
        isCanProxy = value;
    }

    public void setQuit(boolean value) {
        isQuit = value;
    }

    public void build() {
        //frame.setIconImage(null);

        // Setting the width and height of frame
        dialog.setSize(290, 140);
        dialog.setIconImage(Show.getImage());
        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setResizable(false);
        final JPanel panel = new JPanel();
        dialog.add(panel);
        if (isQuit) {
            dialog.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    super.windowClosed(e);
                    conn.getSafeExit().exit(0);
                }
            });
        }

        panel.setLayout(null);

        final JLabel userLabel = new JLabel("Account:");

        userLabel.setBounds(10, 10, 80, 25);
        panel.add(userLabel);

        userText = new JTextField(20);
        userText.setBounds(100, 10, 170, 25);
        panel.add(userText);
        userText.addKeyListener(new turnPasswd());


        final JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 40, 80, 25);
        panel.add(passwordLabel);

        passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 40, 170, 25);
        panel.add(passwordText);
        passwordText.addKeyListener(new turnLogin());

        if (isCanSignUp) {
            JButton signUpBtn = new JButton("SignUp");
            signUpBtn.setBounds(100, 70, 80, 25);
            panel.add(signUpBtn);
            signUpBtn.addActionListener(new SingUpBtnPress());
        }
        if (isCanProxy) {
            JButton proxyBtn = new JButton("Proxy");
            proxyBtn.setBounds(10, 70, 80, 25);
            panel.add(proxyBtn);
            proxyBtn.addActionListener(new proxyBtnPress());
        }

        final JButton loginButton = new JButton("login");
        loginButton.setBounds(190, 70, 80, 25);
        panel.add(loginButton);
        loginButton.addActionListener(new LoginPress());
        Beautiful.setMid((Window) dialog);

        dialog.setVisible(true);

    }

    public String[] get(){
        try{
            while (!loginBtnPressed) {
                if (!dialog.isVisible()) {
                    return null;
                }
                Thread.sleep(20);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return inf;
    }

    public void setProsyCallBack(Net.proxySetter proxy) {
        this.proxySetter = proxy;
    }

    class turnLogin implements KeyListener {
        public void keyReleased(final KeyEvent e) {
        }

        public void keyTyped(final KeyEvent e) {
        }

        public void keyPressed(final KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                new LoginPress().actionPerformed(new ActionEvent(0, 0, ""));
            }
        }
    }

    class turnPasswd implements KeyListener {
        public void keyReleased(final KeyEvent e) {
        }

        public void keyTyped(final KeyEvent e) {
        }

        public void keyPressed(final KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                passwordText.requestFocus();
            }
        }
    }

    class LoginPress implements ActionListener {
        public void actionPerformed(final ActionEvent e) {
            if (userText.getText().equals("") || String.valueOf(passwordText.getPassword()).equals("")) {
                Show.floatWindow((Window) dialog,"Account or passwd can't be empty",800);
                return;
            }
            inf = new String[]{userText.getText(), String.valueOf(passwordText.getPassword())};
            loginBtnPressed = true;
            dialog.dispose();
        }
    }

    class proxyBtnPress implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new SetProxyGUI(proxySetter);
        }
    }

    class SingUpBtnPress implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new SignUp((Window) dialog, conn);
        }
    }
}