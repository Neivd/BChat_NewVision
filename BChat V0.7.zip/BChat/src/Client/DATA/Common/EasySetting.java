package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;

public class EasySetting {
    String title;
    SingleEasySetting[] singleEasySettings;
    static Event event=Event.getInstance();

    public static void main(String[] args) {
        Beautiful.setUIFont();
        new EasySetting(new SingleEasySetting[]{new SingleEasySetting("1","2",()-> Show.m("?????","nmsl")),
                                                new SingleEasySetting("3","4",()-> Show.m("!!","nmsl")),
                                                SingleEasySetting.createSkinChooserSingleEasySetting()}).build();
    }
    public EasySetting(String title,SingleEasySetting[] singleEasySettings){
        this.title=title;
        this.singleEasySettings=singleEasySettings;
    }
    public EasySetting(SingleEasySetting[] singleEasySettings){
        this("Setting",singleEasySettings);
    }
    public void build(){
        JFrame jf=new JFrame(title);
        jf.setIconImage(Show.getImage());
        jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        Box mainPane= Box.createVerticalBox();
        for(SingleEasySetting i:singleEasySettings){
            Box singleSetting=Box.createHorizontalBox();
            singleSetting.add(new JLabel(i.getLabel()));
            singleSetting.add(Box.createHorizontalGlue());
            JButton button=new JButton(i.getBtn());
            button.addActionListener((e)-> i.getRun().run());
            singleSetting.add(button);
            mainPane.add(singleSetting);
        }
        jf.setContentPane(Beautiful.CreatScroll(mainPane));
        Beautiful.setBorder(mainPane);
        jf.setMinimumSize(new Dimension(400,400));
        Beautiful.setMid(jf);
        jf.setVisible(true);
    }
}
