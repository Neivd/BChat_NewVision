package Client.DATA.Common;

import com.google.gson.JsonSyntaxException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Beautiful {
    static Event event=Event.getInstance();
    public static void setUIFont() {
        Font font = new Font("Dialog", Font.PLAIN, 14);
        UIManager.put("Label.font", new Font("Dialo", Font.PLAIN, 16));
        java.util.Enumeration keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof javax.swing.plaf.FontUIResource)
                UIManager.put(key, font);
        }
        try {
            String guiSettingsText=Tools.readFile("GUISetting.json");
            GUISetting.guiSetting=Tools.GSON.fromJson(guiSettingsText,GUISetting.class);
            GUISetting.guiSetting.setGUI();
            //UIManager.setLookAndFeel(GUISetting.guiSetting.getGUI());
        } catch (FileNotFoundException | JsonSyntaxException e) {
            e.printStackTrace();
            event.add(Event.Warn,"Didn't find GUI info,create new one");
            GUISetting.guiSetting=new GUISetting();
            GUISetting.guiSetting.resetAll();
            GUISetting.saveGUISetting();
            setUI(UIManager.getSystemLookAndFeelClassName());
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            event.add(Event.Warn,"set skin failed");
            GUISetting.guiSetting.resetGUI_now();
            GUISetting.saveGUISetting();
            setUI(UIManager.getSystemLookAndFeelClassName());
        }
    }
    public static Exception setUI(String UI){
        try {
            UIManager.setLookAndFeel(UI);
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return e;
        }
    }

    public static void setMid(Window frame) {
        final int windowWidth = frame.getWidth();
        final int windowHeight = frame.getHeight();
        final Toolkit kit = Toolkit.getDefaultToolkit();
        final Dimension screenSize = kit.getScreenSize();
        final int screenWidth = screenSize.width;
        final int screenHeight = screenSize.height;
        //System.out.println(screenHeight);
        //System.out.println(screenWidth);
        frame.setLocation(screenWidth / 2 - windowWidth / 2, screenHeight / 2 - windowHeight / 2);
    }
    public static JTextArea createText(){
        return createText("");
    }
    public static JTextArea createText(String info){
        return createText(info,false);
    }
    public static JTextArea createText(String info,boolean editable){
        JTextArea txt=new JTextArea(info);
        txt.setEditable(editable);
        txt.setWrapStyleWord(true);
        txt.setLineWrap(true);
        return txt;

    }
    public static JScrollPane CreatScroll(JComponent component){
        return new JScrollPane(component,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    }
    public static void setSuitableMinSize(Window f){
        f.pack();
        f.setMinimumSize(new Dimension(f.getWidth(), f.getHeight()));
    }
    public static void setBorder(JComponent jComponent){
        jComponent.setBorder(new EmptyBorder(10,10,10,10));
    }
}
