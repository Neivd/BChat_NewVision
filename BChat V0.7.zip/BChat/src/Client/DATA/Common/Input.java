package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;

public class Input {
    JFrame jf;
    public Input(String info,Window window,MsgInterface msgInterface){
        jf=new JFrame("Input");
        jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        JTextField textField=new JTextField();
        jf.add(new JLabel(info), BorderLayout.NORTH);
        jf.add(textField);
        
        jf.add(new ButtonItem("input",(e)-> {
            jf.dispose();
            msgInterface.message(textField.getText());
            }).getButton(),BorderLayout.EAST);

        jf.setIconImage(Show.getImage());
        Beautiful.setBorder((JComponent) jf.getContentPane());
        Beautiful.setSuitableMinSize(jf);
        jf.setLocationRelativeTo(window);
    }
    public Input setTitle(String title){
        jf.setTitle(title);
        return this;
    }
    public void show(){
        jf.setVisible(true);
    }
}
