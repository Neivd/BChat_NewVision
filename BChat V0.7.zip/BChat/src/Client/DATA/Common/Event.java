package Client.DATA.Common;

import java.util.ArrayList;
import java.util.Date;

/*
event rank:
0 All
*1 Track
2 Debug
*3 Info
*4 Warn
*5 Error
*6 Fatal
7 Off
 */
public class Event {
    private static Event event=null;
    public static final int All=0;
    public static final int Track=1;
    public static final int Debug=2;
    public static final int Info=3;
    public static final int Warn=4;
    public static final int Error=5;
    public static final int Fatal=6;
    public static final int Off=7;
    public static String[] rankList={"All","Track","Debug","Info","Warn","Error","Fatal","Off"};
    static boolean isDebug=true;
    static String type;
    public static Event instanceEvent(String type){
        if(event==null){
            System.out.println("instance event");
            event=new Event(type);
            return event;
        }else {
            throw new RuntimeException("event can't instance more time");
        }
    }
    private Event(String type){
        Event.type=type;
    }
    public static Event getInstance(){
        if(event==null){
            event=new Event("test");
        }
        return event;
    }
    ArrayList<singleEvent> events=new ArrayList<>();
    StringBuilder s=new StringBuilder();
    String buildText(singleEvent e){
        s.replace(0,s.length(),"");
        s.append("[");
        s.append(e.time);
        s.append("][");
        s.append(rankList[e.rank]);
        s.append("]");
        if(e.title!=null){
            s.append("<");
            s.append(e.title);
            s.append(">");
        }
        s.append(e.info);
        return s.toString();
    }
    public void setDebug(boolean tf){
        isDebug=tf;
    }
    public void add(Exception e){
        add(e.toString());
    }
    public void add(int rank,String info){
        add(rank,null,info);
    }
    public void add(String info){
        add(1,info);
    }
    public void add(int rank,String title,String info){
        add(rank,title,info,false);
    }
    public void add(int rank,String title,String info,boolean isGraph){
        singleEvent thisEvent=new singleEvent(rank,title,info,isGraph);
        events.add(thisEvent);
        if(isDebug){
            System.out.println(thisEvent);
        }
    }
    public void add(Object o){
        add(o.toString());
    }
    Date getDate(){
        return new Date();
    }
    String getTime(){
        return this.getDate().toString();
    }
    public ArrayList<singleEvent> getAll(){
        return events;
    }
    public void showAll(){
        for (singleEvent i:events){
            System.out.println(i);
        }
    }
    public void displayAll(){
        for(singleEvent e:events){
            e.display();
        }
    }
    public static void main(String[] args) {
        System.out.println("---------------Testing events------------");
        Event event=new Event("test");
        Beautiful.setUIFont();
        event.add(All,"program running");
        event.add(Track,"server start");
        event.add(Debug,"the value of i is 13");
        event.add(Info,"!!","message receive",true);
        event.add(Warn,"socket connection closed");
        event.add(Error,"can't analyze info");
        event.add(Fatal,"socket closed unexpected");
        event.add(Off,"Crash","kernel socketserver stopped running",true);
        event.add(8,"a wrong info");
        //event.showAll();
        //event.displayAll();

    }
    public String getType(){
        return type;
    }
    public class singleEvent{
        String time;
        String title;
        String info;
        int rank;
        String text;
        public singleEvent(String info){
            this(1,info);//1:Track
        }
        public singleEvent(int rank,String info){
            this(rank,null,info);
        }
        public singleEvent(int rank,String title,String info){
            this(rank,title,info,false);
        }
        public singleEvent(int rank,String title,String info,boolean isGraph){
            int max=rankList.length-1;
            if (rank >=max){
                add(5,"rank beyond max,change to rank7(Off) auto");
                rank=max;
            }
            this.time=getTime();
            this.info=info;
            this.title=title;
            this.rank=rank;
            if(isGraph){
                display();
            }
        }
        String getRank(){
            return rankList[rank];
        }
        @Override
        public String toString() {
            if(text==null){
                text=buildText(this);
            }
            return text;
        }
        public void display(){
            if(rank>=5){
                Show.event(this,true);
                return;
            }
            Show.event(this);
        }
    }
}
