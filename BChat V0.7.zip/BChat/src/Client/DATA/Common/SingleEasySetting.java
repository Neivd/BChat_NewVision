package Client.DATA.Common;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SingleEasySetting {
    static Event event = Event.getInstance();
    private final String label;
    private final String btn;
    private final Runnable run;
    public static String[] all = {"System look",
            "com.jtattoo.plaf.fast.FastLookAndFeel",
            "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel",
            "javax.swing.plaf.metal.MetalLookAndFeel",
            "com.sun.java.swing.plaf.mac.MacLookAndFeel",
            "com.sun.java.swing.plaf.windows.WindowsLookAndFeel",
            "com.sun.java.swing.plaf.motif.MotifLookAndFeel",
            "com.sun.java.swing.plaf.gtk.GTKLookAndFeel",
            "com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel"};

    public SingleEasySetting(String label, String btn, Runnable run) {
        this.label = label;
        this.btn = btn;
        this.run = run;
    }

    public String getLabel() {
        return label;
    }

    public String getBtn() {
        return btn;
    }

    public Runnable getRun() {
        return run;
    }

    public static SingleEasySetting createSkinChooserSingleEasySetting() {
        return new SingleEasySetting("Change skin", "Choose",Show.createSkinChooser());
    }

}
