package Client.DATA.Common;

import java.net.Proxy;

public interface ProxyPcl {
    String[] Proxy_Types ={"HTTP","socket4","socket5","None"};
    int HTTP=0;
    int socket4=1;
    int Socket5=2;
    int None=3;
    void setProxy(Proxy proxy);
    void notProxy();
}
