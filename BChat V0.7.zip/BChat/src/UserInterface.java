import Client.DATA.Common.*;
import Client.DATA.Common.Event;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class UserInterface {
    private final JFrame jf;
    Event event=Event.getInstance();
    Safe safe=Safe.getInstance();
    JList<String> list=new JList<>();
    ButtonItem[] buttons;

    public UserInterface(String title,Safe safe){
        jf=new JFrame(title);
        this.safe=safe;
    }
    public UserInterface(){
        jf=new JFrame("nmsl");
        System.out.println("Warn,this test mode is danger");
    }

    public static void main(String[] args) {
        Beautiful.setUIFont();
        new UserInterface().build();
    }
    ActionListener exitAction;
    void  build(){
        exitAction=(e)->Show.confirm(jf,"Confirm","Are you sure exit?",()->safe.exit(0));
        Box rightBox=Box.createVerticalBox();
        Box leftPane= Box.createVerticalBox();
        leftPane.add(new JLabel("Online:"));
        leftPane.add(list);
        JPanel mainPane = new JPanel(new BorderLayout());
        mainPane.add(leftPane,BorderLayout.CENTER);
        mainPane.add(rightBox,BorderLayout.EAST);

        buttons=new ButtonItem[]{new ButtonItem("Exit",exitAction)};

        for(ButtonItem i:buttons){
            rightBox.add(i.getButton());
        }
        jf.setIconImage(Show.getImage());
        jf.setContentPane(mainPane);
        jf.setMinimumSize(new Dimension(500,400));
        Beautiful.setBorder(mainPane);
        Beautiful.setMid(jf);
        setTray();
        jf.setVisible(true);
    }
    void setTray(){
        TrayMenuItem[] trayMenuItems={new TrayMenuItem("Quit",exitAction),
                new TrayMenuItem("Show/Hide",(e)->jf.setVisible(!jf.isShowing()))};
        PopupMenu popupMenu =new PopupMenu();
        int i;
        for(i= trayMenuItems.length-1;i>=0;i--){
            popupMenu.add(trayMenuItems[i].getMenuItem());
        }
        TrayIcon trayIcon=new TrayIcon(Show.getImage(),"BChat server",popupMenu);
        trayIcon.setImageAutoSize(true);
        trayIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                switch (e.getButton()) {
                    case MouseEvent.BUTTON1: {
                        event.add("托盘图标被鼠标左键被点击");
                        if (!jf.isShowing()) {
                            jf.setVisible(true);
                        }
                        break;
                    }
                    case MouseEvent.BUTTON2: {
                        event.add("托盘图标被鼠标中键被点击");
                        break;
                    }
                    case MouseEvent.BUTTON3: {
                        event.add("托盘图标被鼠标右键被点击");
                        break;
                    }
                }
            }
        });
        SystemTray systemTray=SystemTray.getSystemTray();
        try {
            systemTray.add(trayIcon);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }
}
