import Client.DATA.Common.Beautiful;
import Client.DATA.Common.Event;
import Client.DATA.Common.Pcl;
import Client.DATA.Common.Safe;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class BChatServer {
    static Event event=Event.instanceEvent("Server");
    Safe safe=Safe.getInstance();
    MsgIO tools=new MsgIO();

    ServerSocket serverSocket;
    Map<String,KeepConnection> onLineSocket=new HashMap<>();
    int port=8001;
    Users user=new Users(100);
    UserInterface ui =new UserInterface();
    public static void main(String[] args) {
        Beautiful.setUIFont();
        new BChatServer().build();
    }
    void build(){
        user.makeTestUser();
        try {
            serverSocket = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
        event.add(Event.Track,"ServerSocket started");
        ui.build();
        while (true){
            String[] loginInfo;
            Socket socket;
            try {
                event.add("Wait for connection");
                socket = serverSocket.accept();
                event.add("Accept a connection");
                loginInfo = readInfo(socket);
            //deal with login information
            switch (loginInfo[0]){
                case Pcl.toServer.Verify_Account:
                    //loginInfo[1] is UID
                    //loginInfo[2] is password
                    String theUID=loginInfo[1];
                    if(user.Login(theUID,loginInfo[2])){
                        //Login succ

                        if(onLineSocket.containsKey(theUID)){
                            onLineSocket.get(theUID).forceOffline();
                        }
                        this.send("1",socket);
                        onLineSocket.put(theUID,new KeepConnection(user.all.get(theUID),socket,user,tools));
                    }else {
                        //Login failed
                        send(Pcl.toClient.NAME_AND_PASSWD_RIGHT,socket);
                    }
                    break;
                case Pcl.toServer.Apply_New_Account:
                    if(user.addNewUser(loginInfo[1],loginInfo[2],loginInfo[3])){
                        send(Pcl.toClient.SIGNUP_SUCC,socket);
                    }else {
                        sendList(new String[]{Pcl.toClient.Sign_Up_Failure,"this name has been used"}
                        ,socket);
                    }
            }
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
        }
    }
    public void send(String msg,Socket socket) {
        event.add("sending:" + msg);
        try {
            OutputStream os = socket.getOutputStream();//字节输出流
            PrintWriter pw = new PrintWriter(os);//将输出流包装为打印流
            pw.write(msg);
            pw.write(Pcl.Stop_Char_String);
            pw.flush();
            //socket.shutdownOutput();//关闭输出流
            //Thread.sleep(20);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void sendList(String[] info,Socket socket) {
        StringBuilder content = new StringBuilder();
        for (int i = 0; i < info.length - 1; i++) {
            content.append(info[i]).append(Pcl.Split_Char);
        }
        content.append(info[info.length - 1]);
        send(content.toString(),socket);
    }
    String[] readInfo(Socket socket) throws IOException {
        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb=new StringBuilder();
        int a;
        while ((a = in.read()) != 4) {
            //event.add(a);
            //event.add("in while");
            if (a == -1) {
                event.add(Event.Info,"Can not get information from client,out of connection");
                //Show.m("WARN", "Can not connect the client");
                //safe.exit(-2);
                break;
            }
            sb.append((char) a);
        }
        String[] inBox=sb.toString().split(Pcl.Split_Char);
        event.add(Arrays.toString(inBox));
        return inBox;
    }
    class MsgIO {
        Event getEvent(){
            return event;
        }
        Map<String,KeepConnection> getOnlineSocket(){
            return onLineSocket;
        }
    }
}
