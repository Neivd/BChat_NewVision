import DATA.packages.*;

import java.awt.*;

public class BChat {
    Net net;

    public static void main(String[] args){
        new BChat().build();
    }

    private void build(){
        //Show.m("info",System.getProperty("user.dir"));
        if(!SystemTray.isSupported()){
            Show.m("Warning","Your system do not support system tray.some features may be influenced");
        }
        Show.init();
        Beautiful.setUIFont();
        net=new Net(Information.IP, Information.com);
        net.run();

    }

}