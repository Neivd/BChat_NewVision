package DATA.packages;

import java.util.ArrayList;
import java.io.Serializable;
public class SettingList implements Serializable{
    public static final short CHOICE = 0;
    public static final short TEXT=1;
    public static final short ACCOUNT=2;
    public static final short BOOLVALUE=3;
    public String head="Setting";
    public ArrayList<Single> everyone= new ArrayList<>();
    public SettingList(){}
    public SettingList(String s){
        head=s;
    }
    public SettingList(String s, ArrayList<Single> i){
        this.head=s;
        this.everyone=i;
    }
    public void add(Single i){
        this.everyone.add(i);
    }
    public void setTitle(String t){
        this.head=t;
    }
}
