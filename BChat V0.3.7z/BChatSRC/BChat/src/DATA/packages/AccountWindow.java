package DATA.packages;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.InetSocketAddress;
import java.net.Proxy;

public class AccountWindow {
    JPasswordField passwordText;
    JTextField userText;
    public String[]  inf;
    WindowFunction dialog;
    Net.sendMsg conn;
    ProxyPcl proxySetter;
    public boolean ifCanSignUp =false;
    public boolean ifCanProxy=false;
    boolean loginBtnPressed=false;
    boolean ifQuit=false;
    public void setConn(Net.sendMsg conn){
        this.conn=conn;
    }
    public AccountWindow(WindowFunction jf){
        if(jf instanceof Dialog) {
            dialog = new UniversalDialog((Dialog) jf, "Account", true);
        }else {
            dialog = new UniversalDialog((Frame) jf, "Account", true);
        }
    }
    public AccountWindow(Window jf,boolean modal){
        dialog =new UniversalDialog((Dialog) jf,modal);
    }
    public AccountWindow(){dialog=new UniversalFrame("Account");}
    public void setSignUp(boolean value){
        ifCanSignUp =value;
    }
    public void setProxy(boolean value){ifCanProxy=value;}
    public void setIfQuit(boolean value){ifQuit=value;}
    public void build() {
        //frame.setIconImage(null);

        // Setting the width and height of frame
        dialog.setSize(290, 140);
        dialog.setIconImage(Show.getImage());
        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setResizable(false);
        final JPanel panel = new JPanel();    
        dialog.add(panel);
        if(ifQuit){
            dialog.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    super.windowClosed(e);
                    System.exit(0);
                }
            });
        }
 
        panel.setLayout(null);

        final JLabel userLabel = new JLabel("Account:");
 
        userLabel.setBounds(10,10,80,25);
        panel.add(userLabel);
 
        userText = new JTextField(20);
        userText.setBounds(100,10,170,25);
        panel.add(userText);
        userText.addKeyListener(new turnPasswd());

 
        final JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10,40,80,25);
        panel.add(passwordLabel);
 
        passwordText = new JPasswordField(20);
        passwordText.setBounds(100,40,170,25);
        panel.add(passwordText);
        passwordText.addKeyListener(new turnLogin());

        if(ifCanSignUp) {
            JButton signUpBtn = new JButton("SignUp");
            signUpBtn.setBounds(100, 70, 80, 25);
            panel.add(signUpBtn);
            signUpBtn.addActionListener(new SingUpBtnPress());
        }
        if(ifCanProxy){
            JButton proxyBtn = new JButton("Proxy");
            proxyBtn.setBounds(10, 70, 80, 25);
            panel.add(proxyBtn);
            proxyBtn.addActionListener(new proxyBtnPress());
        }

        final JButton loginButton = new JButton("login");
        loginButton.setBounds(190, 70, 80, 25);
        panel.add(loginButton);
        loginButton.addActionListener(new LoginPress());
        Beautiful.setMid((Window) dialog);

        dialog.setVisible(true);

    }
    public String[] get(){
        while(!loginBtnPressed){
            if (!dialog.isVisible()){
                return null;
            }
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return inf;
    }
    public void setProsyCallBack(ProxyPcl proxy){
        this.proxySetter =proxy;
    }

     class turnLogin implements KeyListener{
        public void keyReleased (final KeyEvent e){ }
        public void keyTyped (final KeyEvent e){ }
        public void keyPressed (final KeyEvent e) {
            if (e.getKeyCode()==KeyEvent.VK_ENTER){
                new LoginPress().actionPerformed(new ActionEvent(0,0,""));
            }
        }
    }
     class turnPasswd implements KeyListener {
        public void keyReleased (final KeyEvent e){   }
        public void keyTyped (final KeyEvent e){   }
        public void keyPressed (final KeyEvent e) { 
            if (e.getKeyCode()==KeyEvent.VK_ENTER){
                passwordText.requestFocus();
            }
         }
    }
     class LoginPress implements ActionListener {
        public void actionPerformed(final ActionEvent e){
            if(userText.getText().equals("") || String.valueOf(passwordText.getPassword()).equals("")){
                return;
            }
            inf=new String[] {userText.getText(), String.valueOf(passwordText.getPassword())};
            loginBtnPressed=true;
            dialog.dispose();
        }
    }
    class proxyBtnPress implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            SettingList st=new SettingList("Proxy");
            var s1=Single.makeTextBtn("IP");
            var s2=Single.makeTextBtn("com");
            st.add(s1);
            st.add(s2);
            Setting set=new Setting((Window) dialog,st);
            set.setCallBack(() -> proxySetter.setProxy(new Proxy(
                    Proxy.Type.HTTP,
                    new InetSocketAddress(
                            s1.getValue(),
                            Integer.parseInt(s2.getValue())))));
            set.build();
        }
    }
    class SingUpBtnPress implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new SignUp((Window) dialog,conn);
        }
    }
}