package DATA.packages;

import java.awt.*;
import java.awt.event.*;

public class test2 {

    private final TextArea tArea = new TextArea(4, 50);
    private final Frame frame = new Frame("PopupMenu");
    PopupMenu popupMenu = new PopupMenu();
    CheckboxMenuItem autoWrap = new CheckboxMenuItem("Auto Wrap");
    MenuItem copyItem = new MenuItem("Copy");
    MenuItem pasteItem = new MenuItem("Paste");
    Menu format = new Menu("Format");
    MenuItem commentItem = new MenuItem("Comment", new MenuShortcut(KeyEvent.VK_SLASH, true));
    MenuItem cancelItem = new MenuItem("Cancel");

    public void init() {
        ActionListener menuListener = e -> {
            // TODO Auto-generated method stub
            String cmd = e.getActionCommand();
            tArea.append("Clicked "+ cmd +" Menu " + "\n");
            if (cmd.equals("Cancel")) {
                System.exit(0);
            }
        };

        commentItem.addActionListener(menuListener);
        // 为pop菜单添加菜单项
        popupMenu.add(autoWrap);
        popupMenu.addSeparator();
        popupMenu.add(copyItem);
        popupMenu.add(pasteItem);

        format.add(commentItem);
        format.add(cancelItem);
        popupMenu.add(new MenuItem("-"));
        popupMenu.add(format);


        final Panel panel = new Panel();
        panel.setPreferredSize(new Dimension(300, 160));
        panel.add(popupMenu);
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                // TODO Auto-generated method stub
                super.mouseReleased(e);
                // 如果释放的是鼠标右键
                if (e.isPopupTrigger()) {
                    System.out.println(e.getX());
                    System.out.println(e.getY());
                    popupMenu.show(panel, e.getX(), e.getY());
                }
            }
        });

        frame.add(panel);
        frame.add(tArea, BorderLayout.NORTH);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // TODO Auto-generated method stub
                super.windowClosing(e);
                System.exit(0);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new test2().init();
    }
}