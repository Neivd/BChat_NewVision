package DATA.packages;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;

public class UniversalFrame extends JFrame implements WindowFunction {
    public UniversalFrame() throws HeadlessException {
        super();
    }

    public UniversalFrame(GraphicsConfiguration gc) {
        super(gc);
    }

    public UniversalFrame(String title) throws HeadlessException {
        super(title);
    }

    public UniversalFrame(String title, GraphicsConfiguration gc) {
        super(title, gc);
    }

    public void add(JPanel panel) {
        super.add(panel);
    }

    public void addWindowListener(WindowAdapter windowAdapter) {
        super.addWindowListener(windowAdapter);
    }

    public void setLocationRelativeTo(Object o) {
        super.setLocationRelativeTo((Component) o);
    }

    public void setContentPane(JScrollPane scrollPane) {
        super.setContentPane(scrollPane);
    }
}
