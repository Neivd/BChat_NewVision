package DATA.packages;

import javax.accessibility.AccessibleContext;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;

public interface WindowFunction {
    void	addNotify();
    AccessibleContext getAccessibleContext();
    String	getTitle();
    boolean	isResizable();
    void setVisible(boolean b);
    void setTitle(String title);
    void setResizable(boolean resizable);

    void setDefaultCloseOperation(int disposeOnClose);

    void setSize(int i, int i1);

    void add(JPanel panel);

    void dispose();

    void addWindowListener(WindowAdapter windowAdapter);

    void setLocationRelativeTo(Object o);

    void setIconImage(Image image);

    void setContentPane(JScrollPane scrollPane);

    boolean isVisible();
}
