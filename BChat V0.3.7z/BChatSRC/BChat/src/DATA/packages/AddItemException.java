package DATA.packages;

public class AddItemException extends Exception{
    String info;
    public AddItemException(String info){
        this.info=info;
    }
    public  void printStackTrace(){
        System.err.println(info);
    }
}
