package DATA.packages;

public class Information {
    public static String IP="127.0.0.1";
    public static int com=8001;
}
