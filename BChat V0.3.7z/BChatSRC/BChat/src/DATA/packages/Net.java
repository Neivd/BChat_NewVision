package DATA.packages;

import java.io.*;
import java.net.Proxy;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

public class Net implements Runnable{
    MUI mainUI;
    Socket socket;
    String IP;
    int com;
    char splitChar=(char)30;
    String inBox;
    String myID;
    String[] loginInfo;
    boolean ifProxy=false;
    sendMsg msgIO=new sendMsg();
    //boolean ifConn=false;
    public String[] frds;
    public boolean status=false;
    //Net self=this;
    Proxy myProxy;
    boolean ifBuildGUI =false;
    public static void main(String[] args){    }
    public  Net(String IP,int com){
        this.IP=IP;
        this.com=com;
/*        try {
            socket = new Socket(IP,com);
            //socket.setKeepAlive(true);
            //ifConn=true;
        }catch (IOException e){
            Show.m("Error","Network Error");
            e.printStackTrace();
            System.exit(0);
        }*/
    }
    void recv()throws IOException{
        InputStream is = socket.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(is, StandardCharsets.US_ASCII));
        StringBuilder sb=new StringBuilder();
        ArrayList<String[]> inBoxMsg=new ArrayList<>();
        while (true) {
            int a;
            sb.delete(0,sb.length());
            while ((a = in.read()) != 4) {
                //System.out.println(a);
                //System.out.println("in while");
                if(a==-1){
                    System.out.println("Can not get information from server");
                    Show.m("WARN","Can not connect the server");
                    System.exit(-2);
                    break;
                }
                sb.append((char) a);
            }

            inBox = sb.toString();
            System.out.println(inBox);
            //socket.shutdownInput();
            //is.close();
            //in.close();
            switch (inBox) {
                case "0":
                    if(!status) {
                        System.out.println("close socket");
                        socket.shutdownInput();
                        socket.shutdownOutput();
                        socket.close();
                        Show.m("ERROR", "Passwd or account Error");
                        return;
                    }
                    Show.m("ERROR", "Passwd or account Error");
                    break;
                case "1":
                    status = true;
                    System.out.println("Login succ");
                    send("2");

                    break;
                case "2":
                    if(!status) {
                        socket.close();
                    }
                    Show.m("ERROR", "Your account is already online");
                    break;
                case "3":
                    send("3");//tell service online
                    break;
                case "4":
                    socket.close();
                    Show.m("succ","apply account success");
                    return;
                default://mean with other args
                    System.out.println("in default method");
                    String[] list=inBox.split((String.valueOf((char)30)));
                    System.out.println(list[0]);
                    switch (list[0]){
                        case "0":
                            System.out.println("Getting Friends");
                            frds= Arrays.copyOfRange(list,1,list.length);//need splitting
                            if (frds[0].equals(String.valueOf((char) 26))){
                                frds=new String[] {};//if it's (char)26,mean no Friend
                            }
                            System.out.println(Arrays.toString(frds));
                            if (ifBuildGUI) {
                                mainUI.jf.dispose();
                                mainUI.systemTray.remove(mainUI.trayicon);
                            }
                            makeRun(new BuildGUI());
                            break;
                        case "1":
                            System.out.println(Arrays.toString(list));
                            while (mainUI ==null) {//make sure MainUI has been created already
                                try {
                                    Thread.sleep(10);
                                }catch (InterruptedException e){
                                    e.printStackTrace();
                                }
                            }
                            while (!mainUI.ifCreated){
                                try {
                                    Thread.sleep(10);
                                }catch (InterruptedException e){
                                    e.printStackTrace();
                                }
                            }
                            try {
                                mainUI.addItem(list);
                                for(String[] i:inBoxMsg){
                                    mainUI.addItem(i);
                                }
                                inBoxMsg.clear();
                                break;
                            } catch (AddItemException e) {
                                e.printStackTrace();
                                System.out.println("try solve problem");
                                inBoxMsg.add(list);
                                msgIO.reFreshFriends();
                            }

                            break;
                        case "2":
                            Show.m("Sign up failed",list[1]);
                            socket.close();
                            return;//close this function
                        case "3":
                            mainUI.addFriendPane.update(Arrays.copyOfRange(list,1,list.length));
                            break;
                        case "4":
                            switch (list[1]) {
                                case "0":
                                    msgIO.reFreshFriends();
                                    Show.m("Warning", "Unfortunately,your friend has deleted you already");
                                    break;
                                case "1":
                                    Show.m("INFO",list[2]);
                            }
                    }
            }
            inBox=null;
        }
    }
    public  void run(){

        int i=0;
        while(i<10){
            try {
                new Login().run();//load Login UI and send info
                i=0;
                recv();
            } catch (IOException  e) {
                i++;
                connSocket();
                System.out.println("Error:Network Error");
            }
        }
        Show.m("Error","Bad Network");
    }
    public static void makeRun(Runnable thing){
        Thread newThread=new Thread(thing);
        newThread.start();
    }
    public void send(String msg){
        System.out.println("sending:"+msg);
        try{
            OutputStream os = socket.getOutputStream();//字节输出流
            PrintWriter pw = new PrintWriter(os);//将输出流包装为打印流
            pw.write(msg);
            //pw.write((char)4);
            pw.flush();
            //socket.shutdownOutput();//关闭输出流
            Thread.sleep(20);

        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
    }
    public void sendList(String[] info){
        StringBuilder content=new StringBuilder();
        for(int i=0;i<info.length-1;i++){
            content.append(info[i]).append(splitChar);
        }
        content.append(info[info.length-1]);
        send(content.toString());
    }
    public void verify(String[] info) {
        connSocket();
        String msg="0"+splitChar+info[0]+splitChar+info[1];
        send(msg);
        //return status;
    }
    class Login implements Runnable{
        public void run(){
                AccountWindow acc=new AccountWindow();
                acc.setSignUp(true);
                acc.setProxy(true);
                acc.setIfQuit(true);
                acc.setConn(msgIO);
                acc.setProsyCallBack(new proxySetter());
                acc.build();
                loginInfo=acc.get();
                if (loginInfo == null){
                    loginInfo=new String[] {"",""};
                }else
                myID=loginInfo[0];
                verify(loginInfo);
        }
    }
    class BuildGUI implements  Runnable{
        public void run(){
            mainUI =new MUI(myID);
            mainUI.msgIO=msgIO;
            ArrayList<Friend> frdArray=new ArrayList<>();
            for(String i:frds){
                frdArray.add(new Friend(i));
            }
            Friends friends =new Friends(myID);
            friends.addAllFrd(frdArray);
            mainUI.friends = friends;
            ifBuildGUI =true;
            mainUI.build();
        }
    }
    class proxySetter implements ProxyPcl {

        @Override
        public void setProxy(Proxy proxy) {
            ifProxy=true;
            myProxy=proxy;
        }
    }
    class sendMsg {
        public void sendData(String frdName, String s) {
            String msg="1"+splitChar+frdName+splitChar+s;
            send(msg);
        }
        public void connAndSend(String[] s) {
            connSocket();
            sendList(s);
        }
        public void recvMsg() {
            try {
                recv();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void sendListData(String[] s) {
            sendList(s);
        }
        void reFreshFriends(){
            send("2");
        }
        void sendData(String msg){
            send(msg);
        }
    }
    public void connSocket(){
        try {
            if(ifProxy){
                socket=new Socket(myProxy);//there are some problems

            }else {
                socket = new Socket(IP, com);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
