package DATA.packages;

import javax.swing.*;
import java.awt.*;

public class Show {
    static ImageIcon icon;
    static boolean ifBuff=false;
    static Image image;
    public static void init(){
        try{
            icon=new ImageIcon("src\\DATA\\packages\\block.png");
            image = Toolkit.getDefaultToolkit().getImage("src\\DATA\\packages\\block.png");
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("error");
        }
        ifBuff=true;
    }
    public static void m(String t,String msg){
        //System.out.println(System.getProperty("user.dir"));
        JOptionPane.showMessageDialog(null, msg,t,JOptionPane.INFORMATION_MESSAGE);
    }
    public static void m(Window frame,String t,String msg){
        JOptionPane.showMessageDialog(frame,msg,t,JOptionPane.INFORMATION_MESSAGE);
    }
    public static void showPhoto(){
        JFrame jf=new JFrame("test");
        jf.setIconImage(getImage());
        jf.getContentPane().add(new JLabel(getIco()));
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.pack();
        jf.setSize(300,300);
        Beautiful.setMid(jf);
        jf.setVisible(true);
    }
    public static void main(String[] args){
        System.out.println(System.getProperty("user.dir"));
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<10000;i++){
            sb.append("?");
        }
        m(sb.toString(),sb.toString());
        //showPhoto();
        //m("title","test,test,test,test,test,test,test.");
    }
    
    public static ImageIcon getIco(){
        if(!ifBuff){
            init();
        }
        return(icon);
    }
    public static Image getImage(){
        if(!ifBuff){
            init();
        }
        return(image);
    }
    public static boolean TF(Window frame){
        return TF(frame,"Ture or False");
    }
    public static boolean TF(Window frame,String log){
        boolean value = false;
        int op=JOptionPane.showConfirmDialog(null,log, "Choice", JOptionPane.YES_NO_CANCEL_OPTION);
        if(op !=2 && op !=-1){
            switch (op){
                case 0:
                    value=true;
                    break;
                case 1:
                    value=false;
                    break;
            }
        }
        return value;
    }
}