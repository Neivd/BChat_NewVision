package DATA.packages;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class AddFriend {
    Net.sendMsg msgio;
    JFrame jf;
    JTextField searchField=new JTextField();
    JPanel otherUser=new JPanel();
    String ID="SB";
    public AddFriend(Net.sendMsg msgIO,String ID){
        this.msgio=msgIO;
        this.ID=ID;
        build();
    }
    public AddFriend(){
        System.out.println("Warning,this mode is danger");

    }

    public static void main(String[] args) {
        Beautiful.setUIFont();

        AddFriend a=new AddFriend();
        a.build();
        a.setVisible(true);
        String[] friends=new String[100];
        for(int i=0;i< friends.length;i++){
            friends[i]= String.valueOf(i);
        }
        a.update(friends);

    }
    public void build(){
        jf=new JFrame("Add Friend For "+ID);
        Box searchBar=Box.createHorizontalBox();
        searchBar.setBorder(new EmptyBorder(10,10,10,10));
        searchBar.add(new JLabel("Find:"));
        searchBar.add(searchField);
        JButton searchBtn=new JButton("Search");
        searchBtn.addActionListener(new sendInfo());
        searchField.addKeyListener(new KeyListener(){
            @Override
            public void keyTyped(KeyEvent e) { }
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode()==KeyEvent.VK_ENTER){
                    new sendInfo().actionPerformed(new ActionEvent(0,0,null));
                }
            }
            @Override
            public void keyReleased(KeyEvent e) {}
        });
        searchBar.add(searchBtn);
        jf.add(searchBar, BorderLayout.NORTH);
        jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        
        /*JScrollPane otherUserScrollPane=new JScrollPane(otherUser,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);*/
        otherUser.setBorder(new EmptyBorder(0,10,10,10));
        jf.setMinimumSize(new Dimension(500,500));
        jf.setIconImage(Show.getImage());
        jf.add(otherUser,BorderLayout.CENTER);
        jf.setSize(800,600);
        Beautiful.setMid(jf);
        //jf.setVisible(true);
    }
    public void setVisible(boolean value){
        if(jf.isShowing()!=value) {
            jf.setVisible(value);
        }
    }
    public void update(String[] users){
        for(String i:users){
            JButton temp=new JButton(i);
            otherUser.add(temp);
            temp.addActionListener(new eachBtn(i));
        }
        otherUser.updateUI();
    }
    class eachBtn implements ActionListener{
        String name;
        public eachBtn(String name){
            this.name=name;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if(Show.TF(jf,"Are you sur add: "+name)) {
                System.out.println("apply for adding " + name);
                msgio.sendListData(new String[]{"7", name});
                msgio.reFreshFriends();
            }else {
                System.out.println("Cancel add friend");
            }
        }
    }
    class sendInfo implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            otherUser.removeAll();
            //Show.m(jf,"title","!");
            if(searchField.getText().equals("")){
                msgio.sendListData(new String[]{"6"});
            }else {
                msgio.sendListData(new String[]{"6",searchField.getText()});
            }
        }
    }
}
