package DATA.packages;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.*;

public class MUI {
    public  Net.sendMsg msgIO;
    public Friends friends;
    Box Pa;
    JPanel Pb;
    Box Me;
    Box FriendTab;
    Box GroupTab;
    JPanel talk;
    JTextArea txt=new JTextArea();
    JTextField sendMsg=new JTextField();
    JPanel[] mePane =new JPanel[4];
    JFrame jf;
    String nameCount;
    boolean face=false;
    String myID;
    AddFriend addFriendPane;
    boolean ifCreated=false;
    TrayIcon trayicon;
    SystemTray systemTray;
    public void addItem(String[] list) throws AddItemException {
        //this func is for add msg to the window
        String msg="Recv: "+list[2] + "\n";
        if (nameCount!=null) {
            if (friends.nameMap.get(nameCount).name.equals(list[3])) {
                txt.append(msg);
            }
        }
        try{
            (friends.nameMap.get(list[3])).text.add(msg);
        }catch (NullPointerException e){
            throw new AddItemException("no such friend");
        }
    }
    public void addItem(String msg){
        if (nameCount!=null) {
                txt.append(msg);
        }
        (friends.nameMap.get(nameCount)).text.add(msg);
    }
    public static void main(String[] args){
        Beautiful.setUIFont();
        Friend pig=new Friend("250");
        pig.name="pig";
        ArrayList<String> temp= new ArrayList<>();
        temp.add("pig");
        pig.text=temp;
        Friends l=new Friends("1");
        l.addFrd(pig);
        MUI m=new MUI("1");
        m.friends =l;
        m.build();
    }
    public MUI (String myID){
        this.myID=myID;
    }
    public void build() {
        jf = new JFrame("BChat: "+myID);
        jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        jf.setSize(800,600);
        jf.setIconImage(Show.getImage());
        jf.setLocationRelativeTo(null);
        jf.setMinimumSize(new Dimension(500,500));



        Pa = Box.createVerticalBox();
        Pb=new JPanel(new BorderLayout());
        talk=new JPanel(new BorderLayout());

        JSplitPane splitPane = new JSplitPane();
        splitPane.setLeftComponent(Pa);
        splitPane.setRightComponent(Pb);
        splitPane.setContinuousLayout(true);// 拖动分隔条时连续重绘组件
        splitPane.setOneTouchExpandable(true);// 分隔条上显示快速 折叠/展开 两边组件的小按钮
        splitPane.setDividerSize(5);
        jf.setContentPane(splitPane);


        final JTabbedPane tabbedPane = new JTabbedPane();
        Pa.add(tabbedPane);

        FriendTab=Box.createVerticalBox();
        GroupTab=Box.createVerticalBox();
        Me=Box.createVerticalBox();

        JButton[] MeTableBtn =new JButton[4];
        MeTableBtn[0]=new JButton("About Me");
        MeTableBtn[1]=new JButton("Edit Info");
        MeTableBtn[2]=new JButton("Setting");
        MeTableBtn[3]=new JButton("About");

        int count=0;
        for(JButton i: MeTableBtn){
            if(count==2){
                count++;
                continue;
            }
            i.addActionListener(new MeBtnPress(count));
            count++;
        }
        MeTableBtn[2].addActionListener(new bootSetting());

        for(int i = 0; i< mePane.length; i++){
            mePane[i]=new JPanel();
        }
        mePane[0].add(new JLabel("About Me"));
        mePane[1].add(new JLabel("Edit page"));
        mePane[3].add(new JLabel(Show.getIco()),BorderLayout.WEST);
        mePane[3].add(new JLabel("BChat version:1.0"));

        for(JButton i:MeTableBtn){
            Me.add(i);
        }
        JButton addFrdBtn=new JButton("Add Friend");
        Me.add(addFrdBtn);
        addFriendPane=new AddFriend(msgIO,myID);
        addFrdBtn.addActionListener(e -> addFriendPane.setVisible(true));

        tabbedPane.addTab("Friends", FriendTab);
        tabbedPane.addTab("Groups", GroupTab);
        tabbedPane.addTab("Me", Me);


        for(Friend i: friends.nameMap.values()){
            JButton tb=new JButton(i.name);
            tb.addActionListener(new frdBtnPress(i.name));
            FriendTab.add(tb);
        }


        txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        txt.setFont(new Font("Dialog",Font.PLAIN,16));
        ((DefaultCaret)txt.getCaret()).setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);//make the text area always scroll down
        //为txt设计右键菜单
        JMenuItem[] txtMenuItem=new JMenuItem[2];
        txtMenuItem[0]=new JMenuItem("Clear");
        txtMenuItem[0].addActionListener(e -> txt.setText(""));
        txtMenuItem[1]=new JMenuItem("delete this friend");
        txtMenuItem[1].addActionListener(e -> {
            if(Show.TF(jf,"Are you sure delete this friend: "+nameCount)) {
                msgIO.sendListData(new String[]{"8", nameCount});
                msgIO.reFreshFriends();
            }else {
                System.out.println("Cancel delete: "+nameCount);
            }
        });
        JPopupMenu txtPopMenu=new JPopupMenu();
        for(JMenuItem i:txtMenuItem){
            txtPopMenu.add(i);
        }
        txt.add(txtPopMenu);
        txt.addMouseListener(new MouseAdapter() {
             @Override
             public void mouseReleased(MouseEvent e) {
                 // TODO Auto-generated method stub
                 super.mouseReleased(e);
                 // 如果释放的是鼠标右键
                 if (e.isPopupTrigger()) {
                     txtPopMenu.show(txt, e.getX(), e.getY());
                 }
             }
         });

        sendMsg.setFont(new Font("Dialog",Font.PLAIN,16));
        sendMsg.addKeyListener(new enterPressed());
        talk.add(new JScrollPane(txt,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER));
        talk.add(sendMsg,BorderLayout.SOUTH);
        Pb.add(new JLabel("welcome to BChat"),BorderLayout.NORTH);

        if(SystemTray.isSupported()){        //make system tray
            MenuItem[] trayMenuItem = new MenuItem[5];
            trayMenuItem[0] = new MenuItem("Quit");
            trayMenuItem[0].addActionListener(e -> System.exit(0));
            trayMenuItem[1] = new MenuItem("Hide/show");
            trayMenuItem[1].addActionListener(e -> jf.setVisible(!jf.isShowing()));
            trayMenuItem[2] = new MenuItem("Setting");
            trayMenuItem[2].addActionListener(e -> new bootSetting().actionPerformed(new ActionEvent("", 0, "")));
            trayMenuItem[3] = new MenuItem("Add friend");
            trayMenuItem[3].addActionListener(e -> addFriendPane.setVisible(true));
            trayMenuItem[4]=new MenuItem("Refresh");
            trayMenuItem[4].addActionListener(e -> msgIO.reFreshFriends());
            PopupMenu trayMenu = new PopupMenu();
            for (int i = trayMenuItem.length - 1; i > -1; i--) {
                trayMenu.add(trayMenuItem[i]);
            }
            trayicon = new TrayIcon(Show.getImage(), "BChat:" + myID, trayMenu);
            trayicon.setImageAutoSize(true);
            trayicon.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    switch (e.getButton()) {
                        case MouseEvent.BUTTON1: {
                            System.out.println("托盘图标被鼠标左键被点击");
                            if (!jf.isShowing()) {
                                jf.setVisible(true);
                            }
                            break;
                        }
                        case MouseEvent.BUTTON2: {
                            System.out.println("托盘图标被鼠标中键被点击");
                            break;
                        }
                        case MouseEvent.BUTTON3: {
                            System.out.println("托盘图标被鼠标右键被点击");
                            break;
                        }
                    }
                }
            });
            try {
                systemTray = SystemTray.getSystemTray();
                systemTray.add(trayicon);//creat system tray
            } catch (AWTException e) {
                e.printStackTrace();
            }
        }

        jf.setVisible(true);
        ifCreated=true;
    }
    public class enterPressed implements KeyListener{
        public void keyReleased (final KeyEvent e){ }
        public void keyTyped (final KeyEvent e){ }
        public void keyPressed (final KeyEvent e) {
            if (e.getKeyCode()==KeyEvent.VK_ENTER){
                String message="Me: "+sendMsg.getText()+"\n";
                addItem(message);
                msgIO.sendData(friends.nameMap.get(nameCount).name,sendMsg.getText());
                sendMsg.setText("");
            }
        }
    }
    public static class bootSetting implements ActionListener{
        public void actionPerformed(ActionEvent e){
            Setting.main(new String[] {""});
        }
    }
    public class MeBtnPress implements ActionListener{
        int num;
        public MeBtnPress(int n){
            num=n;
        }
        public void actionPerformed(ActionEvent e){
            face=false;
            Pb.removeAll();
            Pb.add(mePane[num]);
            Pb.updateUI();

        }
    }
    public class frdBtnPress implements ActionListener{
        String thisName;
        public frdBtnPress(String n){
            thisName =n;
        }
        public void actionPerformed(ActionEvent e){
            nameCount= thisName;
            if(!face){
                Pb.removeAll();
                Pb.add(talk);
                setTxtMsg();
                face=false;//mean stay talk interface
            }else {
                setTxtMsg();
            }
        }
        void setTxtMsg(){
            txt.setText("");
            for(String i:(friends.nameMap.get(thisName)).text){
                txt.append(i);
            }
            Pb.updateUI();
        }
    }
}