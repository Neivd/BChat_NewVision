package DATA.packages;


import java.net.Proxy;

public interface ProxyPcl {
    void setProxy(Proxy proxy);
}
