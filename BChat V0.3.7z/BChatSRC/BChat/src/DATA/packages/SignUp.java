package DATA.packages;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class SignUp {
    JDialog jd;
    Net.sendMsg conn;
    JTextField name=new JTextField(20);
    JPasswordField passwd=new JPasswordField(20);
    JPasswordField confirmPasswd=new JPasswordField(20);
    JButton post=new JButton("Apply");
    public  static  void main(String[] args){
        new SignUp(new JFrame(), new Net("", 0).msgIO);
    }
    public SignUp(Window jf, Net.sendMsg conn){
        this.conn=conn;
        jd=new JDialog(jf,"Sign up");
        jd.setIconImage(Show.getImage());
        Box jp=Box.createVerticalBox();
        jd.setContentPane(jp);
        jp.add(new Label("input name below"));
        name.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode()==KeyEvent.VK_ENTER)
                passwd.requestFocus();
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        jp.add(name);
        jp.add(new Label("input password below"));
        passwd.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode()==KeyEvent.VK_ENTER)
                confirmPasswd.requestFocus();
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        jp.add(passwd);
        jp.add(new Label("confirm password"));
        confirmPasswd.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode()==KeyEvent.VK_ENTER){

                    new postData().actionPerformed(new ActionEvent(0,0,"0"));
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        jp.add(confirmPasswd);
        jp.add(new Label());
        post.addActionListener(new  postData());
        jp.add(post);
        jp.setBorder(new EmptyBorder(10, 10, 10, 10)); // 设置边距
        jd.pack();
        Beautiful.setMid(jd);
        jd.setVisible(true);

    }
    class postData implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("pressed");
            String accountName=name.getText();
            String passwd1= String.valueOf(passwd.getPassword());
            String passwd2= String.valueOf(confirmPasswd.getPassword());
            if (passwd1.equals(passwd2) && !passwd1.equals("")){
                jd.dispose();
                String[] info={"4",accountName,passwd1};
                conn.connAndSend(info);
                conn.recvMsg();
            }else {
                Show.m("warning","Passwd not same or empty");
            }
        }
    }
}
