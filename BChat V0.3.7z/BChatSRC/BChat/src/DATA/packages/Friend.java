package DATA.packages;

import java.util.ArrayList;
import java.io.Serializable;
public class Friend implements Serializable{
    public String name;
    public String ID;
    ArrayList<String> f=new ArrayList<String>();
    public ArrayList<String> text=new ArrayList<>();
    int f_now;//the address of File in list
    String dirPath;
    public Friend(String friendID){
        name=friendID;
        dirPath="/History"+friendID; 
    }
    public boolean older(){
        if (f_now< f.size()){
            f_now++;
            text=(ArrayList<String>) BChatFile.read(f.get(f_now));
            return true;
        }
        return false;
    }
    public boolean earlier(){
        if(f_now>f.size()){
            f_now--;
            text=(ArrayList<String>) BChatFile.read(f.get(f_now));
            return true;
        }
        return false;
    }
    public void new_msg(String s){
        text.add(s);
    }
}