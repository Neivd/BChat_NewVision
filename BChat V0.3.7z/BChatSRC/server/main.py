import socket
from users import user
import threading
import time

onlineSituate = {}
classList = {}
u = user(123)
for i in u.see_user():
    onlineSituate[i] = False


def resolve(mag):
    mag = mag.split('\x1e')
    # print(mag)
    return mag


def MakeMsg(s):
    msg = ""
    for j in s:
        msg = msg + j + '\x1e'
    msg = msg[:-1] + '\x04'
    return msg.encode()


command = []


class msgControler:
    global command

    def add(self, i):
        command.append(i)

    def alwaysCheck(self):
        time.sleep(1)
        self.check()

    def check(self):
        for i in command:
            if i[1] in classList.keys():
                thisClass = classList[i[1]]
                if thisClass.canRecv:
                    thisClass.recvMsg(i)
                    del i


control = msgControler()


class thead:
    def __init__(self):
        self.canRecv = False

    def sendListMsg(self, i):
        self.connect.sendall(MakeMsg(i))

    def trySendListMsgOnline(self, toWho, msg):
        if toWho in classList.keys():
            classList[toWho].recvMsg(msg)

    def trySend(self, i):
        if i[1] in classList.keys():
            classList[i[1]].recvMsg(i)
        else:
            control.add(i)

    def recvMsg(self, message):
        self.connect.sendall(MakeMsg(message))

    def postFriend(self):
        msg = "0"
        for i in u.getFrd(self.name):
            print(i)
            msg = msg + '\x1e' + i
        if msg == "0":
            msg += '\x1e' + "\x1a"
        print(msg)
        self.connect.sendall(msg.encode())
        self.connect.sendall(b'\x04')

    def findUser(self, keyword):
        result_ = []
        for i in u.see_user():
            if keyword in i:
                result_.append(i)
        result_.remove(self.name)
        return result_

    def keepConn(self, connect, name):
        self.data = b""
        self.connect = connect
        self.name = name
        # global command
        # connect.settimeout(0)
        self.connect.setblocking(False)
        print("add thread succ:", name)
        # vf = True  # account status
        # count = 0
        try:
            self.msg = "0"
            print("here")
            # self.postFriend()
            self.canRecv = True
            control.check()
            while 1:
                # get information from client
                try:
                    self.data = self.connect.recv(1024)
                except Exception as e:
                    # print(e.args)
                    if e.args[0] == 10054 or e.args[0] == 10038:
                        print(e.args[0])
                        break
                    # vf = False
                    # connect.sendall(b"3" + b'\x04')
                # deal with data
                if self.data != b"":
                    result = resolve(str(self.data, "utf-8"))
                    if result[0] == "1":
                        if result[1] in u.getFrd(self.name):
                            # print(result)
                            result.append(self.name)
                            self.trySend(result)
                            print(command)
                        else:
                            self.sendListMsg(["4", "0"])  # see tips for net
                    elif result[0] == "2":
                        self.postFriend()
                    elif result[0] == "3":
                        pass
                        # count = 0
                        # vf = True
                    elif result[0] == "6":
                        message = ["3"]
                        if len(result) == 1:
                            message.extend(u.see_user())
                            message.remove(self.name)
                            self.sendListMsg(message)
                        else:
                            message.extend(self.findUser(result[1]))
                            self.sendListMsg(message)
                    elif result[0] == "7":
                        print(self.name, "apply for new friend", result)
                        u.addFrd(self.name, result[1])
                    elif result[0] == "8":
                        u.delFrd(result[1], self.name)
                        self.trySendListMsgOnline(result[1], ["4", "0"])
                self.data = b""
        except IOError as e:
            print(e)
        self.connect.close()
        onlineSituate[self.name] = False
        print(self.name, "is offline")
        del self


try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(60)
    print("create socket succ!")

    sock.bind(('localhost', 8001))
    print('bind socket succ!')

    sock.listen(5)
    print('listen succ!')

except:
    print("init socket error!")
'''
不成熟，先禁用
check = threading.Thread(target=control.alwaysCheck(), )
check.setDaemon(True)
check.start()
'''


def acceptConnect():
    while True:
        try:
            print(onlineSituate)
            print("ready to accept connect")
            conn, addr = sock.accept()
            print(addr)

            # conn.settimeout(30)
            print("try to recv info")
            szBuf = conn.recv(1024)
            print("recv succ")
            msg = str(szBuf, "ascii")
            print("recv:" + msg)
            loginInfo = resolve(msg)
            if loginInfo[0] == "0":
                if u.login(loginInfo[1], loginInfo[2]):
                    if not onlineSituate.get(loginInfo[1]):
                        onlineSituate[loginInfo[1]] = True

                        conn.sendall(b"1")
                        conn.sendall(b'\x04')
                        classList[loginInfo[1]] = thead()
                        t = threading.Thread(target=classList[loginInfo[1]].keepConn, args=(conn, loginInfo[1]))
                        t.setDaemon(True)
                        t.start()
                        # control.check()
                    else:
                        conn.sendall(b"2")
                        conn.sendall(b'\x04')
                else:
                    print("try send error info")
                    conn.sendall(b"0")
                    conn.sendall(b'\x04')
            elif loginInfo[0] == "4":
                if u.creat(loginInfo[1], loginInfo[2]):
                    onlineSituate[loginInfo[1]] = False
                    conn.sendall(b"4")
                    conn.sendall(b'\x04')
                else:
                    conn.sendall(MakeMsg(["2", "This name has been used"]))
            # conn.close()
        except Exception as e:
            print(e)


acceptConnect()

"""acceptconnect=threading.Thread(target=acceptConnect())
acceptconnect.setDaemon(True)
acceptconnect.start()"""
